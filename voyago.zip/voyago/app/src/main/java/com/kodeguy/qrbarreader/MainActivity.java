package com.kodeguy.qrbarreader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.kodeguy.qrbarreader.GeneralFragments.AboutFragment;
import com.kodeguy.qrbarreader.GeneralFragments.HelpFragment;
import com.kodeguy.qrbarreader.GeneralFragments.HistoryFragment;
import com.kodeguy.qrbarreader.GeneralFragments.MyCaptureFragment;
import com.kodeguy.qrbarreader.GeneralFragments.SettingsFragment;
import com.kodeguy.qrbarreader.GeneralFragments.accountfragment;
import com.kodeguy.qrbarreader.GeneralFragments.deliverfragment;
import com.kodeguy.qrbarreader.GeneralFragments.homeFragment;
import com.kodeguy.qrbarreader.GeneralFragments.report;
import com.kodeguy.qrbarreader.GeneralFragments.sendfragment;
import com.uber.sdk.android.rides.RequestButton;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private String startingTripLocation;
    private String endingTripLocation;
    private String start_address;
    private String expected_address;
    private RequestButton rbUber;
    // delay to launch nav drawer item, to allow close animation to play
    static final int NAVDRAWER_LAUNCH_DELAY = 250;
    // fade in and fade out durations for the main content when switching between
    // different Activities of the app through the Nav Drawer
    static final int MAIN_CONTENT_FADEOUT_DURATION = 150;
    static final int MAIN_CONTENT_FADEIN_DURATION = 250;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    private FloatingActionButton fab;
    // Navigation drawer:
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;


    // Helper
    private Handler mHandler;

    private LinkedList<Integer> backStack = new LinkedList<Integer>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prmessionnnnnss();
        //getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        //getSupportActionBar().setCustomView(R.layout.newactionbar);
        // getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#620d34")));
        mHandler = new Handler();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());

        if (prefs.getBoolean("firstVisit", true)) {
            WelcomeDialog welcomeDialog = new WelcomeDialog();
            welcomeDialog.show(getFragmentManager(), "WelcomeDialog");
        } else if (savedInstanceState == null) {
            selectItem(0, false);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.map:
                Intent intent2 = new Intent(this, com.btech.navigation.activity.MainActivity.class);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent2);
                break;
            case R.id.share33:
                takeScreenshot();
                //shareIt();
                break;
        }


        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_clear) {
            File sdcard = getFilesDir();
            final File file = new File(sdcard, "history.txt");

            if (!file.exists())
                Toast.makeText(this, getResources().getString(R.string.cannot_clear), Toast.LENGTH_SHORT).show();
            else {
                AlertDialog.Builder deleteDialog = new AlertDialog.Builder(this);
                deleteDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

                    @Override
                    public void onCancel(DialogInterface dialog) {

                    }

                });
                deleteDialog.setMessage(R.string.delete_history);
                deleteDialog.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        file.delete();
                        selectItem(1, false);
                    }
                });

                deleteDialog.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                deleteDialog.show();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    public static class WelcomeDialog extends DialogFragment {

        @Override
        public void onAttach(Activity activity) {
            super.onAttach(activity);
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            LayoutInflater i = getActivity().getLayoutInflater();
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setView(i.inflate(R.layout.welcome_dialog, null));
            builder.setIcon(R.mipmap.ic_launcher);
            builder.setTitle(getActivity().getString(R.string.welcome));
            builder.setPositiveButton(getActivity().getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ((MainActivity) getActivity()).goToNavigationItem(R.id.nav_scan);
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(((MainActivity) getActivity()).getApplicationContext());
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putBoolean("firstVisit", false);
                    editor.commit();
                }
            });
            builder.setNegativeButton(getActivity().getString(R.string.viewhelp), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ((MainActivity) getActivity()).goToNavigationItem(R.id.nav_help);
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(((MainActivity) getActivity()).getApplicationContext());
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putBoolean("firstVisit", false);
                    editor.commit();
                }
            });

            return builder.create();
        }
    }

    public void switchToFragment(Fragment frag, boolean back) {
        Fragment temp = getFragmentManager().findFragmentById(R.id.container);
        if (!back)
            if (temp instanceof MyCaptureFragment)
                backStack.push(0);
            else if (temp instanceof homeFragment)
                backStack.push(0);
            else if (temp instanceof HistoryFragment)
                backStack.push(0);
            else if (temp instanceof accountfragment)
                backStack.push(0);
            else if (temp instanceof sendfragment)
                backStack.push(0);
            else if (temp instanceof deliverfragment)
                backStack.push(0);
            else if (temp instanceof report)
                backStack.push(0);
            else if (temp instanceof Rateus)
                backStack.push(0);
            else if (temp instanceof social)
                backStack.push(0);
            else if (temp instanceof AboutFragment)
                backStack.push(0);
            else if (temp instanceof HelpFragment)
                backStack.push(0);


        getFragmentManager().beginTransaction().replace(R.id.container, frag).addToBackStack("").commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        if (backStack.size() < 1)
            finish();
        else {
            int back = backStack.pop();
            selectItem(back, true);
        }
    }

    public void goBack() {
        getFragmentManager().beginTransaction().replace(R.id.container, new HistoryFragment()).addToBackStack("").commit();

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (getSupportActionBar() == null) {
            setSupportActionBar(toolbar);
        }

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        mNavigationView = (NavigationView) findViewById(R.id.nav_view);
        mNavigationView.setNavigationItemSelectedListener(this);

        selectNavigationItem(getNavigationDrawerID());
        selectNavigationItem(R.id.nav_scan);

        View mainContent = findViewById(R.id.main_content);
        if (mainContent != null) {
            mainContent.setAlpha(0);
            mainContent.animate().alpha(1).setDuration(MAIN_CONTENT_FADEIN_DURATION);
        }
    }

    // set active navigation item
    private void selectNavigationItem(int itemId) {
        for (int i = 0; i < mNavigationView.getMenu().size(); i++) {
            boolean b = itemId == mNavigationView.getMenu().getItem(i).getItemId();
            mNavigationView.getMenu().getItem(i).setChecked(b);
        }
    }

    protected int getNavigationDrawerID() {
        Fragment temp = getFragmentManager().findFragmentById(R.id.container);

        if (temp instanceof MyCaptureFragment)
            return R.id.nav_scan;
        else if (temp instanceof homeFragment)
            return R.id.nav_home;
        else if (temp instanceof HistoryFragment)
            return R.id.nav_history;
        else if (temp instanceof accountfragment)
            return R.id.nav_ac;
        else if (temp instanceof sendfragment)
            return R.id.nav_send;
        else if (temp instanceof deliverfragment)
            return R.id.nav_de;
        else if (temp instanceof SettingsFragment)
            return R.id.nav_settings;
        else if (temp instanceof report)
            return R.id.nav_re;
        else if (temp instanceof Rateus)
            return R.id.nav_rateus;
        else if (temp instanceof social)
            return R.id.nav_social;
        else if (temp instanceof AboutFragment)
            return R.id.nav_about;

        else
            return R.id.nav_scan;
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        final int itemId = item.getItemId();

        return goToNavigationItem(itemId);
    }

    protected boolean goToNavigationItem(final int itemId) {

        // delay transition so the drawer can close
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                callDrawerItem(itemId);
            }
        }, NAVDRAWER_LAUNCH_DELAY);

        mDrawerLayout.closeDrawer(GravityCompat.START);

        selectNavigationItem(itemId);

        return true;
    }

    private void callDrawerItem(final int itemId) {
        selectItem(0, false);

        switch (itemId) {
            case R.id.nav_scan:
                selectItem(0, false);
                break;
            case R.id.nav_home:
                selectItem(1, false);
                break;
            case R.id.nav_history:
                selectItem(2, false);
                break;
            case R.id.nav_ac:
                selectItem(3, false);
                break;
            case R.id.nav_send:
                selectItem(4, false);
                break;
            case R.id.nav_de:
                selectItem(5, false);
                break;
            case R.id.nav_about:
                selectItem(12, false);
                break;
            case R.id.nav_help:
                selectItem(11, false);
                break;
            case R.id.nav_re:
                selectItem(8, false);
                break;
            case R.id.nav_rateus:
                selectItem(9, false);
                break;
            case R.id.nav_social:
                selectItem(10, false);
                break;
            case R.id.nav_settings:
                selectItem(6, false);
                break;
            case R.id.nav_share:
                selectItem(7, false);
                break;
            default:
                selectItem(0, false);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        //mDrawerToggle.onConfigurationChanged(newConfig);
    }

    public void selectItem(int position, boolean back) {
        // update the main content by replacing fragments


        if (position == 0) {
            switchToFragment(new MyCaptureFragment(), back);
            this.setTitle(R.string.app_name);
        } else if (position == 1) {
            switchToFragment(new homeFragment(), back);
            this.setTitle("Home");
        } else if (position == 2) {
            switchToFragment(new HistoryFragment(), back);
            this.setTitle(R.string.history);
        } else if (position == 3) {
            switchToFragment(new accountfragment(), back);
            this.setTitle("Account");
        } else if (position == 4) {
            switchToFragment(new sendfragment(), back);
            this.setTitle("Send");
        } else if (position == 5) {
            switchToFragment(new deliverfragment(), back);
            this.setTitle("Deliver");
        } else if (position == 6) {
            switchToFragment(new SettingsFragment(), back);
            this.setTitle(R.string.title_activity_settings);
        } else if (position == 8) {
            switchToFragment(new report(), back);
            this.setTitle("Report Issue");
        } else if (position == 9) {
            switchToFragment(new Rateus(), back);
            this.setTitle("Report Issue");
        } else if (position == 10) {
            switchToFragment(new social(), back);
            this.setTitle("Report Issue");
        } else if (position == 12) {
            switchToFragment(new AboutFragment(), back);
            this.setTitle(R.string.action_about);
        } else if (position == 11) {
            switchToFragment(new HelpFragment(), false);
            this.setTitle(R.string.action_help);
        } else if (position == 7) {
            this.setTitle(R.string.action_share);
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                String sAux = "Hi,\n" +
                        "I'm using Voyago to send mail. Please connect and save money. Use Voyago when traveling with your available suitcase space.\n";
                sAux = sAux + "\nGet Voyago FREE!\n" +
                        "https://play.google.com/store/apps/details?id=com.Voyago.qr&hl=en \n";
                i.putExtra(Intent.EXTRA_TEXT, sAux);
                startActivity(Intent.createChooser(i, "choose one"));
            } catch (Exception e) {
                //e.toString();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);

    }

    public void prmessionnnnnss() {
        if (checkAndRequestPermissions()) {
            // carry on the normal flow, as the case of  permissions  granted.
        }
    }

    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA);
        int locationPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int locationp = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        int locationp2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (locationPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }
        if (locationp != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (locationp2 != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

    private void takeScreenshot() {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            String mPath = Environment.getExternalStorageDirectory().toString() + "/DCIM/Voyage" + now + ".jpg";

            // create bitmap screen capture
            View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);

            final File imageFile = new File(mPath);

            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            outputStream.close();
            final CharSequence[] items = {"View", "Share",
                    "Cancel"};
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Choose one!");
            builder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int item) {
                    if (items[item].equals("View")) {
                        openScreenshot2(imageFile);
                    } else if (items[item].equals("Share")) {
                        openScreenshot(imageFile);
                    } else if (items[item].equals("Cancel")) {
                        dialog.dismiss();
                    }
                }
            });
            builder.show();
        } catch (Throwable e) {
            // Several error may come out with file handling or DOM
            e.printStackTrace();
        }
    }

    private void openScreenshot(File imageFile) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(imageFile);
        intent.setAction(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT, "I'm shipping an item using Voyago's mobile app (IF SHARING QRCODE DISREGARD). I would like you to inspect the item I'm sending and approve. I have ensured that nothing is illegal and can be transported with safety. \n" +
                "\n" +
                "As a Voyago-er(transporter) you agree\n" +
                "and are aware that anyone shipping illegal guns, illegal narcotics, hazardous chemicals, or contraband items is not permitted. Please click on REPORT ISSUE to file a complaint. Voyago ensures all users safety.\n" +
                "\n" +
                "* Voyago requires all shipments to be examined by both parties. Please view Voyago's Terms & Conditions within the app. if you need more information.\n" +
                "If you need technical assistance with Voyago's products and services please click on REPORT ISSUE.");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.setDataAndType(uri, "image/*");
        startActivity(Intent.createChooser(intent, "choose one"));
    }

    private void openScreenshot2(File imageFile) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        Uri uri = Uri.fromFile(imageFile);
        // intent.setAction(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.setDataAndType(uri, "image/*");
        startActivity(Intent.createChooser(intent, "choose one"));
    }

    //View v1 = getWindow().getDecorView().getRootView();
    //*private void shareIt() {
    //   Uri uri = Uri.fromFile(imagePath);
    //  Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
    //  sharingIntent.setType("image/*");
    //String shareBody = "In Tweecher, My highest score with screen shot";
    // sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "My Tweecher score");
    // sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
    // sharingIntent.putExtra(Intent.EXTRA_STREAM, uri);

    //startActivity(Intent.createChooser(sharingIntent, "Share via"));
    //}

        }




