package com.kodeguy.qrbarreader.Utility;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.WindowManager;

import com.kodeguy.qrbarreader.R;
import com.kodeguy.qrbarreader.slider;

/**
 * Created by Alyabbasi on 9/9/2017.
 */

public class splash extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.splash);
        setViews();
    }

    private void setViews(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(splash.this, slider.class);
                startActivity(i);
                finish();
            }
        }, 3000);
    }
}



