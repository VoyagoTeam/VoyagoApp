package com.kodeguy.qrbarreader;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Alyabbasi on 12/2/2017.
 */

public class signup extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }
}