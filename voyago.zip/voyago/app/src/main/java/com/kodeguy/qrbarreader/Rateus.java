package com.kodeguy.qrbarreader;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


/**
 * Created by Alyabbasi on 10/12/2017.
 */

public class Rateus extends Fragment {

    ImageView imageview;
    ProgressDialog dialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View rootView = inflater.inflate(R.layout.rateus, container, false);
        setView(rootView);
        return rootView;
    }

    private void setView(View rootView) {

        imageview = (ImageView) rootView.findViewById(R.id.imageView111);
        imageview.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                Intent intent = new Intent(android.content.Intent.ACTION_VIEW);

                //Copy App URL from Google Play Store.
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.Voyago.qr&hl=en"));

                startActivity(intent);
            }


        });
    }
}