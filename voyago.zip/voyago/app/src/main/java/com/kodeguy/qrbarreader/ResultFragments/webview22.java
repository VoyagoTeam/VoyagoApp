package com.kodeguy.qrbarreader.ResultFragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import com.kodeguy.qrbarreader.R;

/**
 * Created by Alyabbasi on 9/8/2017.
 */

public class webview22  extends AppCompatActivity {
private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        String mUrl = getIntent().getStringExtra("mUrl");
        webView = (WebView) findViewById(R.id.w1);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(mUrl);
    }
}
