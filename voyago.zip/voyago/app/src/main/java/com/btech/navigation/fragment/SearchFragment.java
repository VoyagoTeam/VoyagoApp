package com.btech.navigation.fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;


import com.bcgdv.asia.lib.fanmenu.FanMenuButtons;
import com.kodeguy.qrbarreader.R;
import com.btech.navigation.activity.BaseActivity;
import com.btech.navigation.adapter.GooglePlacesAutocompleteAdapterNew;
import com.btech.navigation.comman.Util;
import com.btech.navigation.webservice.WSgetLatLongGoogleApi;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


/****************************************************************************
 * @ClassdName:BaseFragment
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is use BaseFragment Of All Fragment .
 ***************************************************************************/

public class SearchFragment extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener, OnMapReadyCallback {

    private GoogleMap googleMap;
    private MapView mapView;
    private ImageView ivCloseSearch;
    private ImageView ivZoomOut;
    private ImageView ivZoomIn;
    private ImageView ivMyLocation;
    private String fulladdress = "";
    private String smallAddress = "";
    private String location = "";
    private String city = "";
    private String state = "";
    private String country = "";
    private String zipcode = "";

    // Reverce map by address
    private AutoCompleteTextView atvPlaces;
    private GetLocationAddressAsync mGetLocationAddressAsync;

    private Bundle SavedInstanceState;
    private Handler rotator;
    private Runnable runnable;
    private LatLng crntLocationLatLng;
    private FloatingActionButton fb_poi;


    final private String APP_ID = "app05d908fd6ef34be78b";
    final private String ZONE_ID = "vzad629a2b637945dbaf";
    final private String TAG = "SearchFragment";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_mapview, null);
        initializeComponent(rootView);


        return rootView;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SavedInstanceState = savedInstanceState;

    }

    private void initializeComponent(View mView) {

        atvPlaces = (AutoCompleteTextView) mView.findViewById(R.id.fragment_create_myglc_tvStartDest);
        mapView = (MapView) mView.findViewById(R.id.mapview);
        ivCloseSearch = (ImageView) mView.findViewById(R.id.activity_mapcurrentLocation_ivCloseSearch);
        ivZoomOut = (ImageView) mView.findViewById(R.id.zoomOut);
        ivZoomIn = (ImageView) mView.findViewById(R.id.zoomIn);
        ivMyLocation = (ImageView) mView.findViewById(R.id.mylocation);

        fb_poi = (FloatingActionButton) mView.findViewById(R.id.fragment_poi_fab);
        ivCloseSearch.setOnClickListener(this);
        ivZoomOut.setOnClickListener(this);
        ivZoomIn.setOnClickListener(this);
        ivMyLocation.setOnClickListener(this);
        mapView.onCreate(SavedInstanceState);


        if (googleMap == null) {
            googleMap = mapView.getMap();

            if (googleMap != null) {
                googleMap.getUiSettings().setMyLocationButtonEnabled(false);
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                googleMap.setMyLocationEnabled(false);
                googleMap.setTrafficEnabled(true);
                googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                googleMap.getUiSettings().setZoomControlsEnabled(false);
            }


        }

        atvPlaces.setAdapter(new GooglePlacesAutocompleteAdapterNew(getActivity()));
        atvPlaces.setOnItemClickListener(this);


       /* googleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {

            @Override
            public void onCameraChange(CameraPosition arg0) {
                crntLocationLatLng = googleMap.getCameraPosition().target;
                googleMap.clear();
                try {
                    new GetLocationAsync(crntLocationLatLng.latitude, crntLocationLatLng.longitude, getActivity()).execute();
                } catch (Exception e) {
                }
            }
        });*/

        // Needs to call MapsInitializer before doing any CameraUpdateFactory calls
        MapsInitializer.initialize(this.getActivity());
        updateUI();


        final FanMenuButtons sub = (FanMenuButtons) mView.findViewById(R.id.myFABSubmenu);

        if (sub != null) {
            sub.setOnFanButtonClickListener(new FanMenuButtons.OnFanClickListener() {
                @Override
                public void onFanButtonClicked(int index) {


                    if (index == 0) {

                        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                    } else if (index == 1) {
                        googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                    } else if (index == 2) {
                        googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                    } else if (index == 3) {
                        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                    }


                    sub.toggleShow();

                }
            });

            if (fb_poi != null) {
                fb_poi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //Toast.makeText(getActivity(),"Testtt",Toast.LENGTH_LONG).show();
                        sub.toggleShow();
                    }
                });
            }
        }
    }





    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap1) {

        googleMap = googleMap1;
        //googleMap.setOnMarkerClickListener(this);
        //googleMap.setOnMyLocationButtonClickListener(this);
        googleMap.setMyLocationEnabled(true);
        googleMap.getUiSettings().setMyLocationButtonEnabled(false);
        googleMap.setTrafficEnabled(true);
        googleMap.getUiSettings().setZoomControlsEnabled(false);

        // updateUI();

    }

    private void updateUI() {


        MapsInitializer.initialize(getActivity());
        String mCurrentLocation = null;

        if (((BaseActivity) getActivity()).getCurrentLocation() != null) {
            mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation();
        }

        if (null != mCurrentLocation) {

            Double lat = Double.valueOf(mCurrentLocation.split(",")[0]); // getlatitute
            Double lng = Double.valueOf(mCurrentLocation.split(",")[1]); // getLongitute
            new GetLocationAsync(lat, lng, getActivity()).execute();



           /* googleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {

                @Override
                public void onCameraChange(CameraPosition arg0) {

                    crntLocationLatLng = googleMap.getCameraPosition().target;

                    try {
                        new GetLocationAsync(crntLocationLatLng.latitude, crntLocationLatLng.longitude,getActivity()).execute();

                    } catch (Exception e) {
                    }
                }
            });
*/
            // getAddressFromLocation(lat, lng, MapCurrentLocationActivity.this);

        } else {
            rotator = new Handler();
            runnable = new Runnable() {
                public void run() {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    updateUI();

                }
            };

            rotator.postDelayed(runnable, 3000);
        }
    }


    private void addressToLatlong(String reference) {

        if (mGetLocationAddressAsync != null && mGetLocationAddressAsync.getStatus() == AsyncTask.Status.PENDING) {
            mGetLocationAddressAsync.execute();
        } else if (mGetLocationAddressAsync == null || mGetLocationAddressAsync.getStatus() == AsyncTask.Status.FINISHED) {
            mGetLocationAddressAsync = new GetLocationAddressAsync(reference, getActivity());
            mGetLocationAddressAsync.execute();
        }


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {


            case R.id.activity_mapcurrentLocation_ivCloseSearch:
                atvPlaces.getText().clear();

                break;


            case R.id.zoomOut:
                googleMap.animateCamera(CameraUpdateFactory.zoomIn());
                break;


            case R.id.zoomIn:
                googleMap.animateCamera(CameraUpdateFactory.zoomOut());
                break;

            case R.id.mylocation:
                setMyLocation();

                break;


            default:
                break;
        }

    }

    private void setMyLocation() {

        try {
            String mCurrentLocation = "";

            if (((BaseActivity) getActivity()).getCurrentLocation() != null) {
                mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation();
            }

            if (null != mCurrentLocation) {

                Double lat = Double.valueOf(mCurrentLocation.split(",")[0]); // getlatitute
                Double lng = Double.valueOf(mCurrentLocation.split(",")[1]); // getLongitute
                LatLng latLng = new LatLng(lat, lng);
                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 18);
                googleMap.animateCamera(cameraUpdate);
            } else {
                buildAlertMessageNoGps();
            }
        } catch (Exception e) {
            e.printStackTrace();
            buildAlertMessageNoGps();
        }


    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private class GetLocationAddressAsync extends AsyncTask<String, Void, String> {

        // boolean duplicateResponse;
        String reference;
        String address;
        String latlong;

        WSgetLatLongGoogleApi mWSgetLatLongGoogleApi;

        public GetLocationAddressAsync(String reference, final Context context) {
            this.reference = reference.split("==")[1];
            this.address = reference.split("==")[0];

        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {


            mWSgetLatLongGoogleApi = new WSgetLatLongGoogleApi(getActivity());
            latlong = mWSgetLatLongGoogleApi.executeService(reference);
            return null;

        }

        @Override
        protected void onPostExecute(String result) {

            double lat = Double.parseDouble(latlong.split(",")[0]);
            double lng = Double.parseDouble(latlong.split(",")[1]);

            // store lat and long
            location = String.valueOf(lat + "," + lng);
            crntLocationLatLng = new LatLng(lat, lng);
            CameraPosition cameraPosition = new CameraPosition.Builder().target(crntLocationLatLng).zoom(14.5f).build();
            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));


            MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_red));
            markerOptions.title("My Location==" + address);
            googleMap.addMarker(markerOptions.position(new LatLng(lat, lng)));


            googleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

                // Use default InfoWindow frame

                @Override
                public View getInfoWindow(Marker arg0) {

                    View v = getActivity().getLayoutInflater().inflate(R.layout.info_window_layout, null);

                    String title = arg0.getTitle();

                    // Getting reference to the TextView to set latitude
                    TextView tvTitle = (TextView) v.findViewById(R.id.map_info_tvTitle);

                    // Getting reference to the TextView to set longitude
                    TextView tbAddress = (TextView) v.findViewById(R.id.map_info_tvAddress);

                    if (title != null && title.contains("==")) {
                        // Setting the title
                        tvTitle.setText("" + title.split("==")[0]);

                        // Setting the address
                        tbAddress.setText("" + title.split("==")[1]);
                    }


                    return v;

                }

                // Defines the contents of the InfoWindow
                @Override
                public View getInfoContents(Marker arg0) {

                    // Getting view from the layout file info_window_layout
                    View v = getActivity().getLayoutInflater().inflate(R.layout.info_window_layout, null);

                    // Returning the view containing InfoWindow contents
                    return v;
                }
            });


            googleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                @Override
                public void onInfoWindowClick(Marker arg0) {

                    String title = arg0.getTitle();
                    // Toast.makeText(getActivity(),"=="+title,Toast.LENGTH_LONG).show();

                    String startingLatLong = null;

                    if (((BaseActivity) getActivity()).getCurrentLocation() != null) {
                        startingLatLong = ((BaseActivity) getActivity()).getCurrentLocation();
                    }

                    Bundle bundle = new Bundle();
                    bundle.putString("startingLatLong", startingLatLong);
                    bundle.putString("endingLatLong", "" + arg0.getPosition().latitude + "," + arg0.getPosition().longitude);
                    bundle.putString("startingAddress", title.split("==")[0]);
                    bundle.putString("endingAddress", title.split("==")[1]);

                    NavigationGoFragment mFragmentSharingRootPath = new NavigationGoFragment();
                    mFragmentSharingRootPath.setArguments(bundle);
                    Util.addNextFragment(getActivity(), mFragmentSharingRootPath, SearchFragment.this, true);


                }
            });

            try {
                //new GetLocationAsync(crntLocationLatLng.latitude, crntLocationLatLng.longitude, getActivity()).execute();

                atvPlaces.setText("" + address);
                atvPlaces.dismissDropDown();
            } catch (Exception e) {
            }


        }


    }

    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity());
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            GooglePlayServicesUtil.getErrorDialog(status, getActivity(), 0).show();
            return false;
        }
    }


    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        Util.hideKeyboard(getActivity());
        String response = (String) adapterView.getItemAtPosition(position);


        if (response.split("===")[1].equalsIgnoreCase("My Location")) {
            updateUI();
        } else {
            addressToLatlong(response);
        }


    }


    private class GetLocationAsync extends AsyncTask<String, Void, String> {

        // boolean duplicateResponse;
        double x, y;
        private Context context;

        public GetLocationAsync(double latitude, double longitude, final Context context) {
            // TODO Auto-generated constructor stub

            x = latitude;
            y = longitude;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {

            location = String.valueOf(x + "," + y);
        }

        @Override
        protected String doInBackground(String... params) {

            Geocoder geocoder = new Geocoder(context, Locale.ENGLISH);

            try {
                List<Address> addressList = geocoder.getFromLocation(x, y, 1);
                StringBuilder sb = new StringBuilder();

                if (addressList != null && addressList.size() > 0) {
                    Address address = addressList.get(0);

                    fulladdress = "";
                    smallAddress = "";

                    if (sb.append(address.getAddressLine(0)) != null) {
                        smallAddress = address.getAddressLine(0);
                        Log.e("", "smallAddress:-" + smallAddress);
                        fulladdress = smallAddress;
                    }

                    if (address.getLocality() != null) {
                        city = address.getLocality();
                        if (!fulladdress.contains(city))
                            fulladdress = fulladdress + " " + city;

                    }
                    if (address.getAdminArea() != null) {
                        state = address.getAdminArea();
                        if (!fulladdress.contains(state))
                            fulladdress = fulladdress + " " + state;

                    }
                    if (address.getPostalCode() != null) {
                        zipcode = address.getPostalCode();
                        if (!fulladdress.contains(zipcode))
                            fulladdress = fulladdress + " " + zipcode;

                    }
                    if (address.getCountryName() != null) {
                        country = address.getCountryName();
                        if (!fulladdress.contains(country))
                            fulladdress = fulladdress + " " + country;

                    }

                }
            } catch (IOException e) {
                Log.e("", "Unable connect to Geocoder", e);
            }
            return null;

        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (fulladdress != null && !fulladdress.isEmpty()) {
                    atvPlaces.setText("" + fulladdress);
                    atvPlaces.dismissDropDown();

                    location = String.valueOf(x + "," + y);
                    crntLocationLatLng = new LatLng(x, y);


                    CameraPosition cameraPosition = new CameraPosition.Builder().target(crntLocationLatLng).zoom(14.5f).build();
                    googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                    googleMap.clear();


                    MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_red));
                    markerOptions.title("My Location==" + fulladdress);
                    googleMap.addMarker(markerOptions.position(new LatLng(x, y)));
                    googleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

                        // Use default InfoWindow frame

                        @Override
                        public View getInfoWindow(Marker arg0) {

                            View v = getActivity().getLayoutInflater().inflate(R.layout.info_window_layout, null);

                            String title = arg0.getTitle();

                            // Getting reference to the TextView to set latitude
                            TextView tvTitle = (TextView) v.findViewById(R.id.map_info_tvTitle);

                            // Getting reference to the TextView to set longitude
                            TextView tbAddress = (TextView) v.findViewById(R.id.map_info_tvAddress);

                            if (title != null && title.contains("==")) {
                                // Setting the title
                                tvTitle.setText("" + title.split("==")[0]);

                                // Setting the address
                                tbAddress.setText("" + title.split("==")[1]);
                            }


                            return v;

                        }

                        // Defines the contents of the InfoWindow
                        @Override
                        public View getInfoContents(Marker arg0) {

                            // Getting view from the layout file info_window_layout
                            View v = getActivity().getLayoutInflater().inflate(R.layout.info_window_layout, null);

                            // Returning the view containing InfoWindow contents
                            return v;

                        }

                    });


                    googleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                        @Override
                        public void onInfoWindowClick(Marker arg0) {

                            String title = arg0.getTitle();
                            // Toast.makeText(getActivity(),"=="+title,Toast.LENGTH_LONG).show();

                            String startingLatLong = null;

                            if (((BaseActivity) getActivity()).getCurrentLocation() != null) {
                                startingLatLong = ((BaseActivity) getActivity()).getCurrentLocation();
                            }

                            Bundle bundle = new Bundle();
                            bundle.putString("startingLatLong", startingLatLong);
                            bundle.putString("endingLatLong", "" + arg0.getPosition().latitude + "," + arg0.getPosition().longitude);
                            bundle.putString("startingAddress", title.split("==")[0]);
                            bundle.putString("endingAddress", title.split("==")[1]);

                            NavigationGoFragment mFragmentSharingRootPath = new NavigationGoFragment();
                            mFragmentSharingRootPath.setArguments(bundle);
                            Util.addNextFragment(getActivity(), mFragmentSharingRootPath, SearchFragment.this, true);


                        }
                    });
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {

        }
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();


        /**
         * It's somewhat arbitrary when your ad request should be made. Here we are simply making
         * a request if there is no valid ad available onResume, but really this can be done at any
         * reasonable time before you plan on showing an ad.
         */

        {
            /**
             * Optionally update location info in the ad options for each request:
             * LocationManager location_manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );
             * Location location = location_manager.getLastKnownLocation( LocationManager.GPS_PROVIDER );
             * ad_options.setUserMetadata( ad_options.getUserMetadata().setUserLocation( location ) );
             */


        }

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (rotator != null) {
            rotator.removeCallbacks(runnable);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
        if (rotator != null) {
            rotator.removeCallbacks(runnable);
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

}