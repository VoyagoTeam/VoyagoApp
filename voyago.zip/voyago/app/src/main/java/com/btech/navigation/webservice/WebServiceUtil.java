package com.btech.navigation.webservice;

import android.content.Context;

import com.kodeguy.qrbarreader.R;
import com.btech.navigation.model.PlaceDetailModal;
import com.btech.navigation.model.SearchModal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * Created by indianic on 09/06/16.
 */

public class WebServiceUtil {

    private Context context;
    private String type;
    private String latlong;
    private String placeid;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    private boolean success;

    public WebServiceUtil(Context context, String type, String latlong) {
        this.context = context;
        this.type = type;
        this.latlong = latlong;

    }

    public WebServiceUtil(String placeid, Context context) {
        this.placeid = placeid;
        this.context = context;
    }

    public ArrayList<SearchModal> getData() throws IOException {
        final OkHttpClient okHttpClient;
        okHttpClient = new OkHttpClient().newBuilder().connectTimeout(10000, TimeUnit.SECONDS).readTimeout(10000, TimeUnit.SECONDS).build();

        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("maps.googleapis.com")
                .addPathSegment("maps")
                .addPathSegment("api")
                .addPathSegment("place").addPathSegment("nearbysearch").addPathSegment("json")
                .addQueryParameter("location", latlong).addQueryParameter("radius", String.valueOf(5000)).addQueryParameter("type", type).addQueryParameter("key", context.getResources().getString(R.string.google_android_api_key))
                .build();

        Request request = new Request.Builder().url(url).build();
        Response response = okHttpClient.newCall(request).execute();
        String res = response.body().string();
       // Log.e("response", res);
        return parseResponse(res);


    }


    public ArrayList<PlaceDetailModal> getPlaceDetail() throws IOException
    {
        final OkHttpClient okHttpClient;
        okHttpClient = new OkHttpClient().newBuilder().connectTimeout(10000, TimeUnit.SECONDS).readTimeout(10000, TimeUnit.SECONDS).build();

        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("maps.googleapis.com")
                .addPathSegment("maps")
                .addPathSegment("api")
                .addPathSegment("place").addPathSegment("details").addPathSegment("json")
                .addQueryParameter("placeid", placeid).addQueryParameter("key", context.getResources().getString(R.string.google_android_api_key))
                .build();

        Request request = new Request.Builder().url(url).build();
        Response response = okHttpClient.newCall(request).execute();
        String res = response.body().string();
       //Log.e("response", res);

        return parseDetail(res);

    }

    public ArrayList<SearchModal> parseResponse(String response) {
        ArrayList<SearchModal> arrayList = new ArrayList<>();
        try {
            final JSONObject jsonObject = new JSONObject(response);
            final JSONArray resultArray = jsonObject.getJSONArray("results");


            if(resultArray.length() > 0)
            {
                setSuccess(true);
            }
            else
            {
                setSuccess(false);
            }

            for (int i = 0; i < resultArray.length(); i++)
            {

                final JSONObject innerObject = resultArray.getJSONObject(i);
                final JSONObject geometryObject = innerObject.getJSONObject("geometry");
                final JSONObject locationObject = geometryObject.getJSONObject("location");
                final String lat = locationObject.getString("lat");
                final String lng = locationObject.getString("lng");
                final String name = innerObject.getString("name");
                final String placeid = innerObject.getString("place_id");
                SearchModal searchModal = new SearchModal();
                searchModal.setLatitude(lat);
                searchModal.setLongitude(lng);
                searchModal.setName(name);
                searchModal.setPlaceid(placeid);
                arrayList.add(searchModal);


            }

        } catch (JSONException e) {
            e.printStackTrace();
            setSuccess(false);
        }

        return arrayList;
    }


    public ArrayList<PlaceDetailModal> parseDetail(String response) {

        ArrayList<PlaceDetailModal> placeDetailModalArrayList = new ArrayList<>();

        try {
            final JSONObject jsonObject = new JSONObject(response);
            final JSONObject innerObject = jsonObject.getJSONObject("result");
            final String address = innerObject.optString("formatted_address");
            final String name = innerObject.optString("name");
            final String phone = innerObject.optString("formatted_phone_number");

            PlaceDetailModal placeDetailModal = new PlaceDetailModal();
            placeDetailModal.setAddress(address);
            placeDetailModal.setName(name);
            if (phone != null) {
                placeDetailModal.setPhone(phone);
            }

            placeDetailModalArrayList.add(placeDetailModal);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return placeDetailModalArrayList;
    }
}
