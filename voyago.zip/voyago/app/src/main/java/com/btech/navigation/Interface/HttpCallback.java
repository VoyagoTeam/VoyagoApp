package com.btech.navigation.Interface;


import com.btech.navigation.model.Weather;

/**
 * Created by rohit on 10/15/15.
 */
public interface HttpCallback {

    public void onSuccess(Weather response);

    public void onFailure(String error);

}