package com.btech.navigation.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.hardware.GeomagneticField;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kodeguy.qrbarreader.R;
import com.btech.navigation.activity.BaseActivity;
import com.btech.navigation.adapter.MapInstractionListAdapter;
import com.btech.navigation.comman.GoogleDirection;
import com.btech.navigation.comman.IconGenerator;
import com.btech.navigation.model.MapInfoModel;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sothree.slidinguppanel.SlidingUpPanelLayout;


import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

import static com.google.android.gms.maps.CameraUpdateFactory.newCameraPosition;
import static com.google.android.gms.maps.CameraUpdateFactory.newLatLng;

/**
 * *************************************************************************
 *
 * @ClassdName:SharingRootPathFragment
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This class is use to connect with companion then Root path starting Trip to end trip drow path.
 * <p/>
 * *************************************************************************
 */

public class NavigationGoFragment extends Fragment implements OnClickListener {


    private RelativeLayout rlListToMap;
    private LinearLayout rlKm;
    private FrameLayout llCallUber;

    private TextView tvInfo;
    private TextView timeKm;
    private TextView timeKm1;

    private ImageView ivLeftPanel;
    private ListView lvMapInstractionInfoList;
    private SlidingUpPanelLayout mLayout;
    private Bundle SavedInstanceState;

    private String startingTripLocation;
    private String endingTripLocation;

    private Boolean checkMapOrList = false;
    private Boolean isAnimateMap = true;
    private GoogleMap googleMap;
    private MapView mapView;
    private ProgressDialog progress;
    private GoogleDirection gd;
    private List<LatLng> listLatLong;
    private ArrayList<MapInfoModel> mapInfoModelList;
    private View overlay;
    private Document mDoc;
    private LatLng start;
    private LatLng end;
    private GeomagneticField geoField;
    private Marker mPositionMarker;
    private Location preLocation = null;
    private Handler handler;
    private TextToSpeech textToSpeech;
    private boolean IsSafeDriving;


    //declaration String
    private String location = "";
    private String title = "";
    private String fromLocatin;
    private String toLocation;
    private String fromAdd;
    private String toAdd;

    private String start_address;
    private String expected_address;

    //Declaration Dialog View
    private Dialog dialogExplolerItem;
    //private BoomMenuButton boomMenuButton;
    private FloatingActionButton fb_poi;
    private Handler rotator;
    private Runnable runnable;
    private boolean isFromTo;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {

        final View view = inflater.inflate(R.layout.fragment_navigation_go, container, false);

        if (!isGooglePlayServicesAvailable()) {
            Toast.makeText(getActivity(), "no_map_support", Toast.LENGTH_LONG).show();
            getActivity().finish();
        }

        initializeComponent(view);
        setupToolbar(view);


        return view;
    }


    private void setupToolbar(View view)
    {

        // Initializing Toolbar and setting it as the actionbar
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.activity_menubar_toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        //((AppCompatActivity) getActivity()).setSupportActionBar(((MainActivity) getActivity()).getToolbar());
        final ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        TextView mTitle = (TextView) toolbar.findViewById(R.id.actionbar_tvTitle);
        mTitle.setVisibility(View.VISIBLE);
        mTitle.setText("NAVIGATION");
        actionBar.show();


        if (actionBar != null) {

            actionBar.setHomeAsUpIndicator(R.drawable.back_btn);
            actionBar.setTitle("");
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setHomeButtonEnabled(true);
        }



    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SavedInstanceState = savedInstanceState;

    }

    protected void initializeComponent(View v)
    {

        mapInfoModelList = new ArrayList<MapInfoModel>();

        getActivity().setResult(Activity.RESULT_CANCELED);
        handler=new Handler();

        rlListToMap = (RelativeLayout) v.findViewById(R.id.fargment_sharing_root_path_rlListToMap);
        rlKm = (LinearLayout) v.findViewById(R.id.rlKm);
        llCallUber=(FrameLayout)v.findViewById(R.id.llCallUber);
        mapView =(MapView)v.findViewById(R.id.mapview);
        mapView.onCreate(SavedInstanceState);

        tvInfo = (TextView) v.findViewById(R.id.fargment_sharing_root_path_tvInfo);
        timeKm = (TextView) v.findViewById(R.id.tvKmTime);
        timeKm1 = (TextView) v.findViewById(R.id.tvKmTime1);
        ivLeftPanel = (ImageView) v.findViewById(R.id.fargment_sharing_root_path_ivLeftPanel);
        lvMapInstractionInfoList = (ListView) v.findViewById(R.id.fargment_sharing_root_path_lvMapInstractionInfo);
        mLayout = (SlidingUpPanelLayout) v.findViewById(R.id.sliding_layout);
        fb_poi = (FloatingActionButton) v.findViewById(R.id.fragment_poi_fab);
        fb_poi.setOnClickListener(this);
        llCallUber.setOnClickListener(this);

        googleMap = mapView.getMap();
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        googleMap.setMyLocationEnabled(true);
        googleMap.setTrafficEnabled(true);
        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        MapsInitializer.initialize(this.getActivity());

        gd = new GoogleDirection(getActivity());
        panelListener();


        Bundle mBundle = getArguments();

        if (mBundle != null) {

            start_address=mBundle.getString("startingAddress");
            expected_address=mBundle.getString("endingAddress");
            setDirection(mBundle.getString("startingAddress"),mBundle.getString("endingAddress"),mBundle.getString("startingLatLong"),mBundle.getString("endingLatLong"));
        }

        //updateUI();


    }



    private void updateUI() {

        LatLng mLatLng;

        if (((BaseActivity) getActivity()).getCurrentLocation() != null) {

            double lat = Double.parseDouble(((BaseActivity) getActivity()).getCurrentLocation().split(",")[0]);
            double lng = Double.parseDouble(((BaseActivity) getActivity()).getCurrentLocation().split(",")[1]);
            mLatLng = new LatLng(lat, lng);


        } else {
            rotator = new Handler();
            runnable = new Runnable() {
                public void run() {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    updateUI();

                }
            };

            rotator.postDelayed(runnable, 3000);
        }
    }

    private Runnable mRunnebleNew = new Runnable()
    {
        public void run()
        {
            Log.e("", "call Handler ");

            if (((BaseActivity) getActivity()).getCurrentLocation() != null)
            {

                String mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation().trim();
                Double lat = Double.valueOf(mCurrentLocation.split(",")[0]); // getlatitute
                Double lng = Double.valueOf(mCurrentLocation.split(",")[1]); // getLongitute


                ArrayList<Float> nearstArr =new ArrayList<Float>();

                for (int i = 0; i < gd.startLocation.size(); i++)
                {

                    Float nearsValue=distance(new LatLng(lat,lng),new LatLng(gd.startLocation.get(i).latitude,gd.startLocation.get(i).longitude));
                    nearstArr.add(nearsValue);

                }


                if(nearstArr.size() > 0)
                {
                    int minIndex = nearstArr.indexOf(Collections.min(nearstArr));

                    Log.e("", "minIndex "+minIndex);


                    if (gd.startLocationInstraction.get(minIndex).contains("left"))
                    {
                        ivLeftPanel.setBackgroundResource(R.drawable.turn_left);

                    }
                    else if (gd.startLocationInstraction.get(minIndex).contains("right"))
                    {
                        ivLeftPanel.setBackgroundResource(R.drawable.turn_right);
                    }
                    else
                    {
                        ivLeftPanel.setBackgroundResource(R.drawable.turn_streat_arro);
                    }

                    tvInfo.setText("" + removeTags(gd.startLocationInstraction.get(minIndex)));


                   // //Log.d("","Minimum distance:"+nearstArr.get(minIndex));

                    //check nearst location Distance > 20 Ml then textToPich

                    if(nearstArr.get(minIndex) < 30)
                    {
                        textToSpeech.speak(removeTags(gd.startLocationInstraction.get(minIndex)).toString(), TextToSpeech.QUEUE_FLUSH, null);
                    }


                }

            }

            handler.postDelayed(mRunnebleNew,5000);
        }
    };


    public static <T extends Comparable<T>> int findMinIndex(final List<T> xs) {
        int minIndex;
        if (xs.isEmpty()) {
            minIndex = -1;
        } else {
            final ListIterator<T> itr = xs.listIterator();
            T min = itr.next(); // first element as the current minimum
            minIndex = itr.previousIndex();
            while (itr.hasNext()) {
                final T curr = itr.next();
                if (curr.compareTo(min) < 0) {
                    min = curr;
                    minIndex = itr.previousIndex();
                }
            }
        }
        return minIndex;
    }

    public  float distance(LatLng current, LatLng last){
        if(last==null)
            return 0;
        Location cL = new Location("");
        cL.setLatitude(current.latitude);
        cL.setLongitude(current.longitude);

        Location lL = new Location("");
        lL.setLatitude(last.latitude);
        lL.setLongitude(last.longitude);

        return lL.distanceTo(cL);
    }


    public String removeTags(String in) {
        int index = 0;
        int index2 = 0;
        while (index != -1) {
            index = in.indexOf("<");
            index2 = in.indexOf(">", index);
            if (index != -1 && index2 != -1) {
                in = in.substring(0, index).concat(in.substring(index2 + 1, in.length()));
            }
        }

        in = in.replace("&nbsp;", " ");
        in = in.replace("(", "");
        in = in.replace(")", "");

        return in;
    }

    private void addIcon(IconGenerator iconFactory, String text, LatLng position) {
        MarkerOptions markerOptions = new MarkerOptions().
                icon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(text))).
                position(position).
                anchor(iconFactory.getAnchorU(), iconFactory.getAnchorV());

        googleMap.addMarker(markerOptions);
    }

    private void DrowPath()
    {
        Double Sourcestr = Double.valueOf(startingTripLocation.split(",")[0]);
        Double Sourceend = Double.valueOf(startingTripLocation.split(",")[1]);

        Double Deststr = Double.valueOf(endingTripLocation.split(",")[0]);
        Double Destend = Double.valueOf(endingTripLocation.split(",")[1]);

        start = new LatLng(Sourcestr, Sourceend);
        end = new LatLng(Deststr, Destend);

        gd.setLogging(true);
        gd.request(start, end, GoogleDirection.MODE_DRIVING);


        googleMap.moveCamera(newLatLng(new LatLng(Sourcestr, Sourceend)));
        //googleMap.animateCamera(CameraUpdateFactory.zoomTo(30));

        //Goole Map 3d View
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(start) // Sets the center of the map to
                .zoom(20)                   // Sets the zoom
                .bearing(getBearing(start, end)) // Sets the orientation of the camera to east
                .tilt(90)    // Sets the tilt of the camera to 30 degrees
                .build();    // Creates a CameraPosition from the builder
        googleMap.animateCamera(newCameraPosition(
                cameraPosition));

        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);


    }

    private float getBearing(LatLng begin, LatLng end)
    {
        double lat = Math.abs(begin.latitude - end.latitude);
        double lng = Math.abs(begin.longitude - end.longitude);
        if (begin.latitude < end.latitude && begin.longitude < end.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)));
        else if (begin.latitude >= end.latitude && begin.longitude < end.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 90);
        else if (begin.latitude >= end.latitude && begin.longitude >= end.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)) + 180);
        else if (begin.latitude < end.latitude && begin.longitude >= end.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 270);
        return -1;
    }

    private Runnable mRunneble = new Runnable()
    {
        public void run()
        {
            Log.e("", "call Handle ");

            if (((BaseActivity) getActivity()).getCurrentLocation() != null)
            {


                String mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation().trim();

                Log.e("", "mCurrentLocation:-" + mCurrentLocation);

                Double lat = Double.valueOf(mCurrentLocation.split(",")[0]); // getlatitute
                Double lng = Double.valueOf(mCurrentLocation.split(",")[1]); // getLongitute

                Log.e("", "latitude:-" + lat + "longitude:-" + lng);
                LatLng crntLocationLatLngNew = new LatLng(lat, lng);


                Double Deststr = Double.valueOf(endingTripLocation.split(",")[0]);
                Double Destend = Double.valueOf(endingTripLocation.split(",")[1]);

                LatLng crntLocationLatLngEnd = new LatLng(Deststr, Destend);

                Location location = ((BaseActivity) getActivity()).getmCurrentLocation();
                //gd.clickMe(googleMap, crntLocationLatLngNew, new LatLng(Deststr, Destend));


                if (location == null)
                    return;


                if (location != null)
                {
                    if (preLocation != null)
                    {
                        Log.e("", "location=="+location.getLatitude()+","+location.getLongitude());
                        Log.e("", "location==Pre=="+preLocation.getLatitude()+","+preLocation.getLongitude());

                        if (distance(location.getLatitude(), location.getLongitude(), preLocation.getLatitude(), preLocation.getLongitude()) > 0)
                        {

                            Log.e("", "location==distance if greate"+preLocation.getLatitude());
                            //float bearing = preLocation.bearingTo(location) ;

                            double bearing=GetBearing(crntLocationLatLngNew,new LatLng(preLocation.getLatitude(),preLocation.getLongitude()));

                            Log.e("", "location==distance bearing"+bearing);

                            preLocation = location;
                            animateMarkerNew(mPositionMarker,Float.parseFloat(new String(String.valueOf(bearing))),location);
                            googleMap.animateCamera(newLatLng(new LatLng(location.getLatitude(), location.getLongitude())));

                        }
                    }
                    else
                    {
                        preLocation = location;

                        if (mPositionMarker == null)
                        {

                            float bearing = preLocation.bearingTo(location) ;
                            mPositionMarker = googleMap.addMarker(new MarkerOptions()
                                    .flat(true)
                                    .icon(BitmapDescriptorFactory
                                            .fromResource(R.drawable.pin_dyrct_blue))
                                    .anchor(0.5f, 0.5f)
                                    .rotation(bearing)
                                    .flat(true)
                                    .position(
                                            new LatLng(location.getLatitude(), location
                                                    .getLongitude())));
                        }

                        // animateMarker(mPositionMarker, location); // Helper method for smooth
                        googleMap.animateCamera(newLatLng(new LatLng(location.getLatitude(), location.getLongitude())));



                    }

                    handler.postDelayed(mRunneble,5000);
                }
            }
        }
    };

    private final double degreesPerRadian = 180.0 / Math.PI;

    private double GetBearing(LatLng from, LatLng to){
        double lat1 = from.latitude * Math.PI / 180.0;
        double lon1 = from.longitude * Math.PI / 180.0;
        double lat2 = to.latitude * Math.PI / 180.0;
        double lon2 = to.longitude * Math.PI / 180.0;

        // Compute the angle.
        double angle = - Math.atan2( Math.sin( lon1 - lon2 ) * Math.cos( lat2 ), Math.cos( lat1 ) * Math.sin( lat2 ) - Math.sin( lat1 ) * Math.cos( lat2 ) * Math.cos( lon1 - lon2 ) );

        if (angle < 0.0)
            angle += Math.PI * 2.0;

        // And convert result to degrees.
        angle = angle * degreesPerRadian;

        return angle;
    }

    /** calculates the distance between two locations in MILES */
    private double distance(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 3958.75; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        double dist = earthRadius * c;

        //Log.d("", "dist:-" + dist);

        return dist; // output distance, in MILES
    }

    public void animateMarkerNew(final Marker marker,final float bearing,final Location location)
    {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final long duration = 500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);


                marker.setPosition(new LatLng(location.getLatitude(), location.getLongitude()));

                //Log.d("","bearing:"+bearing);

                marker.setRotation(bearing);
                marker.setAnchor(0.5f, 0.5f);

                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }



    public void animateMarker(final Marker marker, final Location location,final float bearing)
    {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final LatLng startLatLng = marker.getPosition();
        final double startRotation = marker.getRotation();
        final long duration = 500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run()
            {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);

                double lng = t * location.getLongitude() + (1 - t)
                        * startLatLng.longitude;
                double lat = t * location.getLatitude() + (1 - t)
                        * startLatLng.latitude;

                float rotation = (float) (t * location.getBearing() + (1 - t)
                        * startRotation);

                marker.setPosition(new LatLng(lat, lng));
                marker.setRotation(rotation);

                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }




    /**
     * This Method use check GooglePlay service Avalable or Not
     */
    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity());
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            GooglePlayServicesUtil.getErrorDialog(status, getActivity(), 0).show();
            return false;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {



            case R.id.fragment_poi_fab:

                //AdBuddiz.showAd(getActivity());
                //AdBuddiz.RewardedVideo.show(getActivity());

               /* Bundle bundle = new Bundle();
                DialogSelectDirection mDialogSelectCategory = new DialogSelectDirection();
                mDialogSelectCategory.setTargetFragment(NavigationFragment.this, 99);
                mDialogSelectCategory.show(getFragmentManager(), "");*/


                break;

        }

    }


    private void setDirection(final String startAdd, final String endAdd, String startLatLong, String endLatLong)
    {

        startingTripLocation=startLatLong;
        endingTripLocation = endLatLong;
        title = "Test";


        if(startingTripLocation.isEmpty() && endingTripLocation.isEmpty())
        {
            Toast.makeText(getActivity(),"Please select direction.",Toast.LENGTH_LONG).show();
        }
        else {


            //callWebService();

            progress = new ProgressDialog(getActivity());
            progress.show();
            progress.setMessage("Please wait...");
            progress.setCancelable(false);


            gd.setOnDirectionResponseListener(new GoogleDirection.OnDirectionResponseListener() {
                public void onResponse(String status, Document doc, GoogleDirection gd) {

                    if (progress != null && progress.isShowing()) {
                        progress.dismiss();
                    }

                    if (status.equalsIgnoreCase("OK"))
                    {

                    mDoc = doc;
                    googleMap.addPolyline(gd.getPolyline(doc, 3, Color.BLUE));
                    googleMap.addMarker(new MarkerOptions().position(start)
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_red)).title(startAdd));

                    googleMap.addMarker(new MarkerOptions().position(end)
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_green)).title(endAdd));


                    //gd.animateDirection(googleMap, gd.getDirection(mDoc), GoogleDirection.SPEED_VERY_FAST
                    //		, true, false, true, true, new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.car)), false, true, null);


                    gd.getDirection(mDoc);


                    timeKm.setText("" + gd.getTotalDurationText(mDoc));
                    timeKm1.setText("" + gd.getTotalDistanceText(mDoc));

                    //Log.d("", "startLocation" + gd.startLocation.size());
                    //Log.d("", "startLocationInstraction" + gd.startLocationInstraction.size());

                    if (gd.startLocation.size() > 0) {

                        for (int i = 0; i < gd.startLocation.size(); i++) {

                            MapInfoModel mapModel = new MapInfoModel();
                            String turnInfo = "";
                            String turnInfoDest = "";

                            if (gd.startLocationInstraction.get(i).contains("left")) {
                                turnInfo = "left";

                            } else if (gd.startLocationInstraction.get(i).contains("right")) {
                                turnInfo = "right";
                            } else {
                                turnInfo = "continue";
                            }

                            turnInfoDest = removeTags(gd.startLocationInstraction.get(i));
                            //timeKm.setText("" + removeTags(gd.startLocationInstraction.get(0)));


                            //Log.d("", "turnInfo-" + turnInfo + "==turnInfoDest==" + turnInfoDest);

                            mapModel.setTitle(turnInfo);
                            mapModel.setDescription(turnInfoDest);
                            mapInfoModelList.add(mapModel);

                            IconGenerator iconFactory = new IconGenerator(getActivity());
                            iconFactory.setRotation(90);
                            iconFactory.setContentRotation(-90);
                            iconFactory.setStyle(IconGenerator.STYLE_PURPLE);
                            addIcon(iconFactory, turnInfoDest, new LatLng(gd.startLocation.get(i).latitude, gd.startLocation.get(i).longitude));

                        }

                        MapInstractionListAdapter mMapInfoListAdapter = new MapInstractionListAdapter(getActivity(), mapInfoModelList);
                        lvMapInstractionInfoList.setAdapter(mMapInfoListAdapter);
                        mMapInfoListAdapter.notifyDataSetChanged();

                        //call Handler
                        handler.postDelayed(mRunnebleNew, 5000);

                        //handler.postDelayed(mRunneble,5000);


                    }

                    }
                    else
                    {
                        Toast.makeText(getActivity(),"No Rout Found.",Toast.LENGTH_LONG).show();
                    }
                }
            });

            DrowPath();


            textToSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status != TextToSpeech.ERROR) {
                        textToSpeech.setLanguage(Locale.UK);
                    }
                }
            });


            Animation animation1 = AnimationUtils.loadAnimation(getActivity(), R.anim.blink);
            ivLeftPanel.startAnimation(animation1);

        }


    }


    @Override
    public void onDestroy() {

        super.onDestroy();
        mapView.onDestroy();
        //AdBuddiz.onDestroy(); // to minimize memory footprint

        if (progress != null && progress.isShowing()) {
            progress.dismiss();
        }



        if(handler !=null)
        {
            handler.removeCallbacks(mRunnebleNew);
        }


        if(textToSpeech !=null){
            textToSpeech.stop();
            textToSpeech.shutdown();
        }

    }




    public void onPause() {
        super.onPause();
        gd.cancelAnimated();

        if(handler !=null)
        {
            handler.removeCallbacks(mRunnebleNew);
        }


        if(textToSpeech !=null){
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }




    public String deDup(String s)
    {
        return new LinkedHashSet<String>(Arrays.asList(s.split("-"))).toString().replaceAll("(^\\[|\\]$)", "").replace(", ", "-");
    }


    /**
     * this method call setPanelSlidelistener method to listen open and close of slide panel
     */
    public void panelListener()
    {

        mLayout.setPanelSlideListener(new SlidingUpPanelLayout.PanelSlideListener() {

            // During the transition of expand and collapse onPanelSlide function will be called.
            @Override
            public void onPanelSlide(View panel, float slideOffset) {
                //Log.e(TAG, "onPanelSlide, offset " + slideOffset);
            }

            // This method will be call after slide up layout
            @Override
            public void onPanelExpanded(View panel) {
                //Log.e(TAG, "onPanelExpanded");

            }

            // This method will be call after slide down layout.
            @Override
            public void onPanelCollapsed(View panel) {
                //Log.e(TAG, "onPanelCollapsed");

            }

            @Override
            public void onPanelAnchored(View panel) {
                //Log.e(TAG, "onPanelAnchored");
            }

            @Override
            public void onPanelHidden(View panel) {
                //Log.e(TAG, "onPanelHidden");
            }
        });
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if(handler !=null)
        {
            handler.removeCallbacks(mRunnebleNew);
        }

        if(rotator !=null)
        {
            rotator.removeCallbacks(runnable);
        }
    }



}
