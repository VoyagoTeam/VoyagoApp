package com.btech.navigation.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.btech.navigation.comman.Util;
import com.kodeguy.qrbarreader.R;


/****************************************************************************
 * @ClassdName:BaseFragment
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is use BaseFragment Of All Fragment .
 ***************************************************************************/

public class ExplorerFragment extends Fragment implements View.OnClickListener
{



    private boolean init = false;
    private CardView cvStreeeView;
    private CardView cvWeather;
    private CardView cvSetting;

    final private String APP_ID = "app05d908fd6ef34be78b";
    final private String ZONE_ID = "vzad629a2b637945dbaf";
    final private String TAG = "SearchFragment";
    private boolean isShowAdd=false;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_explorer, null);

        cvStreeeView=(CardView) rootView.findViewById(R.id.cvStreetView);
        cvWeather=(CardView) rootView.findViewById(R.id.cvWeather);


        cvWeather.setOnClickListener(this);
        cvStreeeView.setOnClickListener(this);
        return rootView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



    @Override
    public void onClick(View v) {


        switch (v.getId()) {



            case R.id.cvWeather:
                WeatherFragment mWeatherFragment = new WeatherFragment();
                Util.addNextFragment(getActivity(), mWeatherFragment, ExplorerFragment.this, true);

                break;

            case R.id.cvStreetView:

                StreetViewFragment mCreateGroupFragment = new StreetViewFragment();
                Util.addNextFragment(getActivity(), mCreateGroupFragment, ExplorerFragment.this, true);


                break;


            default:
                break;
        }

    }




    @Override
    public void onResume() {
        super.onResume();

        /**
         * It's somewhat arbitrary when your ad request should be made. Here we are simply making
         * a request if there is no valid ad available onResume, but really this can be done at any
         * reasonable time before you plan on showing an ad.
         */

        {
            /**
             * Optionally update location info in the ad options for each request:
             * LocationManager location_manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );
             * Location location = location_manager.getLastKnownLocation( LocationManager.GPS_PROVIDER );
             * ad_options.setUserMetadata( ad_options.getUserMetadata().setUserLocation( location ) );
             */


        }
    }
}