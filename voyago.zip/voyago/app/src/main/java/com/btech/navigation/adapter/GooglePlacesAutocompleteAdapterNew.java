package com.btech.navigation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import com.kodeguy.qrbarreader.R;
import com.btech.navigation.comman.Util;
import com.btech.navigation.webservice.PlaceAPI;

import java.util.ArrayList;

public class GooglePlacesAutocompleteAdapterNew extends BaseAdapter implements Filterable
{
    private ArrayList<String> resultList;
    private PlaceAPI searchGooglePlace;
    private Context mContext;

    public GooglePlacesAutocompleteAdapterNew(Context context) {
        mContext = context;
    }

    @Override
    public int getCount() {
        return resultList.size();
    }

    @Override
    public String getItem(int index) {
        return resultList.get(index);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {


        final Holder holder;

        if (convertView == null) {
            holder = new Holder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.row_googleserach_listnew, null);
            holder.address = (TextView) convertView.findViewById(R.id.address);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        holder.address.setText(""+resultList.get(position).split("==")[0]);
       return  convertView;
    }

    @Override
    public Filter getFilter() {
        Filter filter = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();
                if (constraint != null) {


                    if (Util.isNetworkAvailable(mContext))
                    {
                        // Retrieve the autocomplete results.
                        searchGooglePlace = new PlaceAPI(mContext);
                        resultList = searchGooglePlace.autocomplete(constraint.toString());


                        //Log.d("","===resultList"+resultList);

                        // Assign the data to the FilterResults
                        filterResults.values = resultList;
                        filterResults.count = resultList.size();

                    }


                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (results != null && results.count > 0) {
                    notifyDataSetChanged();
                } else {
                    notifyDataSetInvalidated();
                }
            }
        };
        return filter;
    }

    class Holder {

        private TextView address;

    }


}