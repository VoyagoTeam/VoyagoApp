package com.btech.navigation.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.res.ColorStateList;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bcgdv.asia.lib.fanmenu.FanMenuButtons;
import com.btech.navigation.activity.BaseActivity;
import com.btech.navigation.comman.Util;
import com.btech.navigation.model.PlaceDetailModal;
import com.btech.navigation.model.SearchModal;
import com.btech.navigation.webservice.WebServiceUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.kodeguy.qrbarreader.R;

import java.io.IOException;
import java.util.ArrayList;

import static com.google.android.gms.maps.CameraUpdateFactory.newCameraPosition;


/****************************************************************************
 * @ClassdName:BaseFragment
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is use BaseFragment Of All Fragment .
 ***************************************************************************/

public class NearByFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMyLocationButtonClickListener,
        View.OnClickListener {


    private GoogleMap map;
    private MapView mapView;
    private Handler rotator;
    private Runnable runnable;
    private Bundle SavedInstanceState;
    private boolean init = false;
    private FloatingActionButton fb_poi;
    private ProgressDialog progress;
    private ImageView ivZoomOut;
    private ImageView ivZoomIn;

    //Declaration Dialog View
    private Dialog dialogSelectNearItem;
    private FloatingActionButton fb_close;
    private ImageView mDialog_addSearchPlace_ivFood;
    private ImageView mDialog_addSearchPlace_ivCafe;
    private ImageView mDialog_addSearchPlace_ivbar;
    private ImageView mDialog_addSearchPlace_ivRestaurant;
    private ImageView mDialog_addSearchPlace_ivBakery;
    private ImageView mDialog_addSearchPlace_ivBookStore;
    private ImageView mDialog_addSearchPlace_ivClothingStore;
    private ImageView mDialog_addSearchPlace_ivElctronicStore;
    private ImageView mDialog_addSearchPlace_ivFurnitureStore;
    private ImageView mDialog_addSearchPlace_ivShoppingMall;
    private ImageView mDialog_addSearchPlace_ivJeweStore;
    private ImageView mDialog_addSearchPlace_ivHardware;
    private ImageView mDialog_addSearchPlace_ivBicycle;
    private ImageView mDialog_addSearchPlace_ivAirport;
    private ImageView mDialog_addSearchPlace_ivBusStation;
    private ImageView mDialog_addSearchPlace_ivGasStation;
    private ImageView mDialog_addSearchPlace_ivParking;
    private ImageView mDialog_addSearchPlace_ivTrainStation;
    private ImageView mDialog_addSearchPlace_ivTaxiStation;
    private ImageView mDialog_addSearchPlace_ivAtm;
    private ImageView mDialog_addSearchPlace_ivBank;
    private ImageView mDialog_addSearchPlace_ivPolice;
    private ImageView mDialog_addSearchPlace_ivCarRepair;
    private ImageView mDialog_addSearchPlace_ivFinance;
    private ImageView mDialog_addSearchPlace_ivLawyer;
    private ImageView mDialog_addSearchPlace_ivPlumber;
    private ImageView mDialog_addSearchPlace_ivPostOffice;
    private ImageView mDialog_addSearchPlace_ivTravles;
    private ImageView mDialog_addSearchPlace_ivGym;
    private ImageView mDialog_addSearchPlace_ivLibrary;
    private ImageView mDialog_addSearchPlace_ivMovieTheater;
    private ImageView mDialog_addSearchPlace_ivHospital;
    private ImageView mDialog_addSearchPlace_ivPark;
    private ImageView mDialog_addSearchPlace_ivStadiam;
    private ImageView mDialog_addSearchPlace_ivCasino;
    private ImageView mDialog_addSearchPlace_ivMusium;
    private ImageView mDialog_addSearchPlace_ivSchool;
    private ImageView mDialog_addSearchPlace_ivUniversity;
    private ImageView mDialog_addSearchPlace_ivCourt;
    private ImageView mDialog_addSearchPlace_ivDentist;
    private ImageView mDialog_addSearchPlace_ivDoctor;
    private ImageView mDialog_addSearchPlace_ivHairCare;


    private String item;
    // private Spinner spinner;
    private String location;
    private ArrayList<SearchModal> arrayList;
    private ArrayList<PlaceDetailModal> placeDetailArray;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_nearbye, null);
        initializeComponent(rootView);
        return rootView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SavedInstanceState = savedInstanceState;

    }


    @SuppressLint("MissingPermission")
    private void initializeComponent(View rootView) {

        mapView = (MapView) rootView.findViewById(R.id.mapview);
        fb_poi = (FloatingActionButton) rootView.findViewById(R.id.fragment_poi_fab);

        ivZoomOut = (ImageView) rootView.findViewById(R.id.zoomOut);
        ivZoomIn = (ImageView) rootView.findViewById(R.id.zoomIn);
        ivZoomOut.setOnClickListener(this);
        ivZoomIn.setOnClickListener(this);

        mapView.onCreate(SavedInstanceState);
        map = mapView.getMap();
        map.getUiSettings().setMyLocationButtonEnabled(true);
        map.setMyLocationEnabled(true);
        map.setTrafficEnabled(true);
        map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        map.getUiSettings().setZoomControlsEnabled(false);
        //fb_poi.setOnClickListener(this);
        // Needs to call MapsInitializer before doing any CameraUpdateFactory calls
        MapsInitializer.initialize(this.getActivity());
        updateUI();
        openAddSearchDailog();


        final FanMenuButtons sub = (FanMenuButtons) rootView.findViewById(R.id.myFABSubmenu);

        if (sub != null) {
            sub.setOnFanButtonClickListener(new FanMenuButtons.OnFanClickListener() {
                @Override
                public void onFanButtonClicked(int index)
                {


                    if(index==0)
                    {
                        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                    }
                    else if(index==1)
                    {
                        map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                    }
                    else if(index==2)
                    {
                        map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                    }
                    else if(index==3)
                    {
                        map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                    }
                    else if(index==4)
                    {
                        openAddSearchDailog();
                    }


                    sub.toggleShow();

                }
            });

            if (fb_poi != null) {
                fb_poi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //Toast.makeText(getActivity(),"Testtt",Toast.LENGTH_LONG).show();
                        sub.toggleShow();
                    }
                });
            }
        }
    }

    private void updateUI() {

        LatLng mLatLng;

        if (((BaseActivity) getActivity()).getCurrentLocation() != null) {

            double lat = Double.parseDouble(((BaseActivity) getActivity()).getCurrentLocation().split(",")[0]);
            double lng = Double.parseDouble(((BaseActivity) getActivity()).getCurrentLocation().split(",")[1]);
            mLatLng = new LatLng(lat, lng);
            //CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(mLatLng, 10);
            //map.animateCamera(cameraUpdate);

            //Goole Map 3d View
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(lat, lng)) // Sets the center of the map to
                    .zoom(20)                   // Sets the zoom
                    .tilt(90)    // Sets the tilt of the camera to 30 degrees
                    .build();    // Creates a CameraPosition from the builder
            map.animateCamera(newCameraPosition(
                    cameraPosition));

            map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
            map.getUiSettings().setZoomControlsEnabled(false);
            MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_red));
            markerOptions.title("My Location");
            map.addMarker(markerOptions.position(mLatLng));

        } else {
            rotator = new Handler();
            runnable = new Runnable() {
                public void run() {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    updateUI();

                }
            };

            rotator.postDelayed(runnable, 3000);
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {


        if (map.getMyLocation() != null) {
            location = String.valueOf(map.getMyLocation().getLatitude()).concat(",").concat(String.valueOf(map.getMyLocation().getLongitude()));
        }


        return false;
    }





    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap1) {

        map = googleMap1;
        map.setOnMyLocationButtonClickListener(this);
        map.setMyLocationEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(false);

    }


    private class MapServiceAsychtask extends AsyncTask<Void, Void, Void>
    {

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
            progress = new ProgressDialog(getActivity());
            progress.show();
            progress.setMessage("Please wait...");
            progress.setCancelable(false);

        }

        @Override
        protected Void doInBackground(Void... params) {

            try {
               // Log.d("MapServiceAsychtask","item=="+item+"==location=="+location);

                arrayList = new WebServiceUtil(getActivity(), item, location).getData();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            map.clear();


            if (progress != null && progress.isShowing()) {
                progress.dismiss();
            }

            if (arrayList != null) {

                for (int i = 0; i < arrayList.size(); i++)
                {
                   // map.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(arrayList.get(i).getLatitude()), Double.parseDouble(arrayList.get(i).getLongitude()))).title(arrayList.get(i).getName()));
                    setMarker(new LatLng(Double.parseDouble(arrayList.get(i).getLatitude()), Double.parseDouble(arrayList.get(i).getLongitude())),arrayList.get(i).getName());
                }

                if(arrayList.size() > 0)
                {
                    //Goole Map 3d View
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(new LatLng(Double.parseDouble(arrayList.get(0).getLatitude()), Double.parseDouble(arrayList.get(0).getLongitude()))) // Sets the center of the map to
                            .zoom(18)                   // Sets the zoom
                            .tilt(90)    // Sets the tilt of the camera to 30 degrees
                            .build();    // Creates a CameraPosition from the builder
                    map.animateCamera(newCameraPosition(
                            cameraPosition));
                    map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                    map.getUiSettings().setZoomControlsEnabled(false);

                    map.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter()
                    {

                        // Use default InfoWindow frame

                        @Override
                        public View getInfoWindow(Marker arg0) {

                            View v = getActivity().getLayoutInflater().inflate(R.layout.info_window_layout, null);

                            String title = arg0.getTitle();

                            // Getting reference to the TextView to set latitude
                            TextView tvTitle = (TextView) v.findViewById(R.id.map_info_tvTitle);

                            // Getting reference to the TextView to set longitude
                            TextView tbAddress = (TextView) v.findViewById(R.id.map_info_tvAddress);
                            tbAddress.setVisibility(View.GONE);
                            if (title != null ) {
                                // Setting the title
                                tvTitle.setText("" + title);

                                // Setting the address
                                //tbAddress.setText("" + title.split("==")[1]);
                            }


                            return v;

                        }

                        // Defines the contents of the InfoWindow
                        @Override
                        public View getInfoContents(Marker arg0) {

                            // Getting view from the layout file info_window_layout
                            View v = getActivity().getLayoutInflater().inflate(R.layout.info_window_layout, null);

                            // Returning the view containing InfoWindow contents
                            return v;

                        }

                    });


                    map.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {

                        @Override
                        public void onInfoWindowClick(Marker arg0) {

                            String title = arg0.getTitle();
                            // Toast.makeText(getActivity(),"=="+title,Toast.LENGTH_LONG).show();

                            String startingLatLong = null;

                            if (((BaseActivity) getActivity()).getCurrentLocation() != null)
                            {
                                startingLatLong = ((BaseActivity) getActivity()).getCurrentLocation();
                            }

                            Bundle bundle = new Bundle();
                            bundle.putString("startingLatLong",startingLatLong);
                            bundle.putString("endingLatLong",""+arg0.getPosition().latitude+","+arg0.getPosition().longitude);
                            bundle.putString("startingAddress","My Location");
                            bundle.putString("endingAddress",title);

                            NavigationGoFragment mFragmentSharingRootPath = new NavigationGoFragment();
                            mFragmentSharingRootPath.setArguments(bundle);
                            Util.addNextFragment(getActivity(), mFragmentSharingRootPath, NearByFragment.this, true);


                        }
                    });

                }
                else
                {
                    Toast.makeText(getActivity(),"No Result Found",Toast.LENGTH_LONG).show();
                }



            }
        }
    }

    private void setMarker(LatLng latLng, String name)
    {
        MarkerOptions markerOptions = null;
        if(item.equalsIgnoreCase("bicycle_store"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_directions_bike_big));
        }
        else if(item.equalsIgnoreCase("airport"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_local_airport_big));
        }
        else if(item.equalsIgnoreCase("bus_station"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_directions_bus_big));

        }
        else if(item.equalsIgnoreCase("gas_station"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_local_gas_station_big));
        }
        else if(item.equalsIgnoreCase("parking"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_local_parking_big));
        }
        else if(item.equalsIgnoreCase("train_station"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_train_big));
        }
        else if(item.equalsIgnoreCase("taxi_stand"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_local_taxi_big));
        }
        else if(item.equalsIgnoreCase("travel_agency"))
        {
            markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_travel_bus));
        }
        markerOptions.title(name);
        map.addMarker(markerOptions.position(latLng));

    }

    private class PlaceDetailAsynch extends AsyncTask<String, Void, Void> {
        private Marker marker;

        PlaceDetailAsynch(Marker marker) {
            this.marker = marker;
        }

        @Override
        protected Void doInBackground(String... params) {


            try {
                placeDetailArray = new WebServiceUtil(params[0], getActivity()).getPlaceDetail();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (placeDetailArray != null) {

                marker.setSnippet(placeDetailArray.get(0).getAddress());
                marker.showInfoWindow();


            }

        }
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();

        if(rotator !=null)
        {
            rotator.removeCallbacks(runnable);
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }


    public void rotateFabForward()
    {
        ViewCompat.animate(fb_close)
                .rotation(45.0F)
                .withLayer()
                .setDuration(1500L)
                .setInterpolator(new OvershootInterpolator(5.0F))
                .start();
    }

    private void setFloatingActionButtonColors(FloatingActionButton fab, int primaryColor, int rippleColor) {
        int[][] states = {
                {android.R.attr.state_enabled},
                {android.R.attr.state_pressed},
        };

        int[] colors = {
                primaryColor,
                rippleColor,
        };

        ColorStateList colorStateList = new ColorStateList(states, colors);
        fab.setBackgroundTintList(colorStateList);
    }

    private void openAddSearchDailog()
    {

        dialogSelectNearItem = new Dialog(getActivity(), R.style.CustomDialogSerach);
        dialogSelectNearItem.setContentView(R.layout.dialog_addseacrh_place);



        mDialog_addSearchPlace_ivBicycle = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivBicycle);
        mDialog_addSearchPlace_ivAirport = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivAirport);
        mDialog_addSearchPlace_ivBusStation = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivBusStation);
        mDialog_addSearchPlace_ivGasStation = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivGasStation);
        mDialog_addSearchPlace_ivParking = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivParking);
        mDialog_addSearchPlace_ivTrainStation = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivTrainStation);
        mDialog_addSearchPlace_ivTaxiStation = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivTaxiStation);


        mDialog_addSearchPlace_ivTravles = (ImageView) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_ivTravles);






         mDialog_addSearchPlace_ivBicycle.setOnClickListener(this);
         mDialog_addSearchPlace_ivAirport.setOnClickListener(this);
         mDialog_addSearchPlace_ivBusStation.setOnClickListener(this);
        mDialog_addSearchPlace_ivGasStation.setOnClickListener(this);
         mDialog_addSearchPlace_ivParking.setOnClickListener(this);
         mDialog_addSearchPlace_ivTrainStation.setOnClickListener(this);
         mDialog_addSearchPlace_ivTaxiStation.setOnClickListener(this);
        mDialog_addSearchPlace_ivTravles.setOnClickListener(this);



        fb_close = (FloatingActionButton) dialogSelectNearItem.findViewById(R.id.dialog_addSearchPlace_fab);
        setFloatingActionButtonColors(fb_close, getResources().getColor(R.color.floting_bg_color), getResources().getColor(R.color.floting_bg_color));
        //fb_close.setImageResource(R.drawable.cancel_btn);
        rotateFabForward();
        Animation animation1 = AnimationUtils.loadAnimation(getActivity(), R.anim.popup_zoom);
        mDialog_addSearchPlace_ivBicycle.startAnimation(animation1);
        mDialog_addSearchPlace_ivAirport.startAnimation(animation1);
        mDialog_addSearchPlace_ivBusStation.startAnimation(animation1);
        mDialog_addSearchPlace_ivGasStation.startAnimation(animation1);
        mDialog_addSearchPlace_ivParking.startAnimation(animation1);
        mDialog_addSearchPlace_ivTrainStation.startAnimation(animation1);
        mDialog_addSearchPlace_ivTaxiStation.startAnimation(animation1);
        mDialog_addSearchPlace_ivTravles.startAnimation(animation1);



        fb_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialogSelectNearItem.dismiss();


            }
        });

        dialogSelectNearItem.setCanceledOnTouchOutside(true);
        dialogSelectNearItem.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialogSelectNearItem.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialogSelectNearItem.show();

    }



    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.dialog_addSearchPlace_ivBicycle:
                item = "bicycle_store";
                openNearPlaces(item);
                break;
            case R.id.dialog_addSearchPlace_ivAirport:
                item = "airport";
                openNearPlaces(item);
                break;

            case R.id.dialog_addSearchPlace_ivBusStation:
                item = "bus_station";
                openNearPlaces(item);
                break;

            case R.id.dialog_addSearchPlace_ivGasStation:
                item = "gas_station";
                openNearPlaces(item);
                break;

            case R.id.dialog_addSearchPlace_ivParking:
                item = "parking";
                openNearPlaces(item);
                break;

            case R.id.dialog_addSearchPlace_ivTrainStation:
                item = "train_station";
                openNearPlaces(item);
                break;

            case R.id.dialog_addSearchPlace_ivTaxiStation:
                item = "taxi_stand";
                openNearPlaces(item);
                break;
            case R.id.dialog_addSearchPlace_ivTravles:
                item = "travel_agency";
                openNearPlaces(item);
                break;
            case R.id.zoomOut:
                map.animateCamera(CameraUpdateFactory.zoomIn());
                break;


            case R.id.zoomIn:
                map.animateCamera(CameraUpdateFactory.zoomOut());
                break;


        }

    }

    private void openNearPlaces(String selectItem)
    {

        item=selectItem;
        dialogSelectNearItem.dismiss();

        if (map.getMyLocation() != null) {
            location = String.valueOf(map.getMyLocation().getLatitude()).concat(",").concat(String.valueOf(map.getMyLocation().getLongitude()));
            new MapServiceAsychtask().execute();
        }

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if(rotator !=null)
        {
            rotator.removeCallbacks(runnable);
        }
    }


}


