package com.btech.navigation.activity;


import android.util.Log;

import com.kodeguy.qrbarreader.R;
import com.stephentuso.welcome.WelcomeScreenBuilder;
import com.stephentuso.welcome.ui.WelcomeActivity;
import com.stephentuso.welcome.util.WelcomeScreenConfiguration;

/**
 * Created by stephentuso on 11/15/15.
 */
public class MyWelcomeActivity extends WelcomeActivity {

    @Override
    protected WelcomeScreenConfiguration configuration()
    {
        return new WelcomeScreenBuilder(this)
                .theme(R.style.CustomWelcomeScreenTheme)
                .defaultTitleTypefacePath("Montserrat-Bold.ttf")
                .defaultHeaderTypefacePath("Montserrat-Bold.ttf")
                .titlePage(R.drawable.navigation_final, "WELCOME", R.color.orange_background)
                .basicPage(R.drawable.navigation_final, "ROUTE FINDER & NAVIGATION", "Search your route finder and easily navigation.", R.color.red_background)
                .parallaxPage(R.layout.parallax_example1, "MAP TYPE AND TRAFFIC ", "Satelite,Terrain,Hybride map and traffic information.", R.color.orange_background)
                .parallaxPage(R.layout.parallax_example, "NEAR BY LOCATION", "Near by Location Cafe,Trasfomation,Food,Restaurant Etc &  best your direction", R.color.purple_background, 0.2f, 2f)
                .basicPage(R.drawable.street_img, "STREETVIEW AND WEATHER", "Explorer places streetview and see your current weather", R.color.blue_background)
                .swipeToDismiss(true)
                .exitAnimation(android.R.anim.fade_out)
                .build();
    }


    public static String welcomeKey()
    {

        Log.d("","");
        return "WelcomeScreen";
    }

}
