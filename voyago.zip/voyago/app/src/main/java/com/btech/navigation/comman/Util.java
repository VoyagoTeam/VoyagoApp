package com.btech.navigation.comman;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.EditText;

import com.kodeguy.qrbarreader.R;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;


public class Util {

    private static final String TAG = Util.class.getSimpleName();

    public static final int REQUEST_ADD_POST_PIC_CROP = 24;
    public static final int REQUEST_CODE_TO_PICK_GALLERY_IMAGE = 21;
    public static final int REQUEST_CODE_TO_CLICK_IMAGE_BY_CAMERA = 22;
    private static boolean isFinishDialog;
    private static final String currentDeviceLanguage = Locale.getDefault().getLanguage();
    public static Fragment curFragment = null;

    public static String getCurrentdevicelanguage() {
        return currentDeviceLanguage;
    }

    /**
     * This function is used for validate email address
     *
     * @param email
     * @return true if email is valid otherwise false
     */
    public static boolean isEmailValid(String email) {
        if (TextUtils.isEmpty(email)) {
            return false;
        } else {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
    }


    /**
     * @param mActivity
     * @param targetedFragment
     * @param shooterFragment
     * @purpose for call targeted fragment from current fragment
     */

    public static void addNextFragment(Activity mActivity, Fragment targetedFragment, Fragment shooterFragment, boolean isDownToUp) {
        final FragmentTransaction transaction = mActivity.getFragmentManager().beginTransaction();



        transaction.add(R.id.activity_menubar_containers, targetedFragment, targetedFragment.getClass().getSimpleName());
        curFragment = targetedFragment;
        transaction.hide(shooterFragment);
        transaction.addToBackStack(targetedFragment.getClass().getSimpleName());
        transaction.commit();
    }

    /**
     * This function is used for validate email address
     *
     * @param htmlData htmlData for add extra html tag for use custom style sheet
     * @return String html tag appended data
     */
    public static String appendCustomStyleSheet(String htmlData) {
        StringBuilder stringBuffer = new StringBuilder();

        stringBuffer.append("<HTML><HEAD><LINK href=\"style.css\" type=\"text/css\" rel=\"stylesheet\"/></HEAD><body>");
        stringBuffer.append(htmlData);
        stringBuffer.append("</body></HTML>");

        return stringBuffer.toString();
    }

    /**
     * @param mActivity
     * @param targetedFragment
     * @param shooterFragment
     * @purpose for call targeted fragment from current fragment
     */






    /**
     * @purpose get the device ID
     * @param context
     * @return
     */
//	public final static String getDeviceID(Context context)
//	{
//		return Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
//	}

    /**
     * Method is used for checking network availability.
     *
     * @param context
     * @return isNetAvailable: boolean true for Internet availability, false otherwise
     */

    public static boolean isNetworkAvailable(Context context) {
        boolean isNetAvailable = false;
        if (context != null) {
            final ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

            if (mConnectivityManager != null) {
                boolean mobileNetwork = false;
                boolean wifiNetwork = false;

                boolean mobileNetworkConnecetd = false;
                boolean wifiNetworkConnecetd = false;

                final NetworkInfo mobileInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                final NetworkInfo wifiInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

                if (mobileInfo != null) {
                    mobileNetwork = mobileInfo.isAvailable();
                }

                if (wifiInfo != null) {
                    wifiNetwork = wifiInfo.isAvailable();
                }

                if (wifiNetwork || mobileNetwork) {
                    if (mobileInfo != null)
                        mobileNetworkConnecetd = mobileInfo.isConnectedOrConnecting();
                    wifiNetworkConnecetd = wifiInfo.isConnectedOrConnecting();
                }

                isNetAvailable = (mobileNetworkConnecetd || wifiNetworkConnecetd);
            }
        }

        return isNetAvailable;
    }




    public static final void dismissProgressDialog(ProgressDialog progressDialog) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }



    public static void displayDialog(final Context context, final String title, final String msg, final String strPositiveText, final String strNegativeText,
                                     final boolean isNagativeBtn, final boolean isFinish) {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setTitle(title);
        dialog.setCancelable(false);
        dialog.setMessage(msg);
        dialog.setPositiveButton(strPositiveText, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
                if (isFinish) {

                    ((Activity) context).getFragmentManager().popBackStack();
                }
            }
        });
        if (isNagativeBtn) {
            dialog.setNegativeButton(strNegativeText, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
        }
        dialog.show();
    }

    /**
     * Method is used for displaying dialog and finishing activity on dialog button click yes isFinish Return true otherwise return false
     *
     * @param title
     * @param msg
     * @param context
     */
    public static Boolean displayDialogFragment(String title, String msg, final Context context) {

        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(title);
        alertDialog.setCancelable(false);
        alertDialog.setMessage(msg);

        alertDialog.setNeutralButton(context.getString(android.R.string.yes), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                isFinishDialog = true;

            }
        }).setNegativeButton(context.getString(android.R.string.no), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                dialog.cancel();
                isFinishDialog = false;
            }
        });

        final AlertDialog dialog = alertDialog.create();

        if (!dialog.isShowing()) {
            alertDialog.show();

        }

        return isFinishDialog;

    }





    /**
     * Hide KeyBoard Using CurrentFocus
     *
     * @return
     */
    public static void hideKeyboard(Context mContext) {
        InputMethodManager inputManager = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);

        View focus = ((Activity) mContext).getCurrentFocus();

        if (focus != null) {

            inputManager.hideSoftInputFromWindow(focus.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * Hide KeyBoard Using CurrentFocus when FragmentDialog
     *
     * @return
     */
    public static void hideKeyboardWithDialog(Context mContext) {
        InputMethodManager inputManager = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);

        View focus = ((Activity) mContext).getCurrentFocus();

        //Log.d("focus", "focus:" + focus);

        if (focus != null) {
            inputManager.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
        }

    }

    public static void openKeyboardWithDialog(Context mContext) {
        InputMethodManager imm = (InputMethodManager)
                mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
        }
    }

    public static void hideKeyboardWithDialogNew(Context mContext) {

        InputMethodManager imm = (InputMethodManager)
                mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY);
        }
    }

    /**
     * @param inputEmail
     * @return
     * @purpose validate email
     */
    public final static boolean isValidEmail(CharSequence inputEmail) {
        if (inputEmail == null) {
            return false;
        } else {
            return Patterns.EMAIL_ADDRESS.matcher(inputEmail).matches();
        }
    }


    /**
     * @param inputURL
     * @return
     * @purpose validate url
     */
    public final static boolean isValidURL(CharSequence inputURL) {
        if (inputURL == null) {
            return false;
        } else {
            return Patterns.WEB_URL.matcher(inputURL).matches();
        }
    }

    public static void displayDialogForFragment(String title, String msg, final Context context, final boolean isFinish) {

        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(title);
        alertDialog.setCancelable(false);
        alertDialog.setMessage(msg);

        alertDialog.setNeutralButton(context.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (isFinish) {
                    ((Activity) context).getFragmentManager().popBackStack();
                }

            }
        });
        final AlertDialog dialog = alertDialog.create();
        if (!((Activity) context).isFinishing()) {
            if (!dialog.isShowing()) {
                alertDialog.show();
            }
        }
    }




    public static void stopScrollNew(AbsListView view) {
        try {
            Field field = AbsListView.class.getDeclaredField("mFlingRunnable");
            field.setAccessible(true);
            Object flingRunnable = field.get(view);
            if (flingRunnable != null) {
                Method method = Class.forName("android.widget.AbsListView$FlingRunnable").getDeclaredMethod("endFling");
                method.setAccessible(true);
                method.invoke(flingRunnable);
            }
        } catch (Exception e) {
        }
    }

    public static void stopRecScroll(AbsListView view) {
        try {
            Field field = AbsListView.class.getDeclaredField("mFlingRunnable");
            field.setAccessible(true);
            Object flingRunnable = field.get(view);
            if (flingRunnable != null) {
                Method method = Class.forName("android.widget.AbsListView$FlingRunnable").getDeclaredMethod("endFling");
                method.setAccessible(true);
                method.invoke(flingRunnable);
            }
        } catch (Exception e) {
        }
    }

    /**
     * Method is used for displaying dialog
     *
     * @param title
     * @param msg
     * @param context
     */

    public static void displayDialogNormalMessage(String title, String msg, final Context context) {

        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(title);
        alertDialog.setCancelable(false);
        alertDialog.setMessage(msg);

        alertDialog.setNeutralButton(context.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();


            }
        });
        final AlertDialog dialog = alertDialog.create();

        if (!((Activity) context).isFinishing()) {
            if (!dialog.isShowing()) {
                alertDialog.show();
            }
        }
    }


    /**
     * Method is used for displaying dialog
     *
     * @param title
     * @param msg
     * @param context
     */
    public static void displayDialogNormalMessageOkPopBack(String title, String msg, final Context context) {

        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(title);
        alertDialog.setCancelable(false);
        alertDialog.setMessage(msg);
        alertDialog.setNeutralButton(context.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                ((Activity) context).getFragmentManager().popBackStack();

            }
        });
        final AlertDialog dialog = alertDialog.create();

        if (!((Activity) context).isFinishing()) {
            if (!dialog.isShowing()) {
                alertDialog.show();
            }
        }
    }

    /**
     * This method converts device specific pixels to device independent pixels.
     *
     * @param px      A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent db equivalent to px value
     */
    public static int convertPixelsToDp(float px, Context context) {
        final Resources resources = context.getResources();
        final DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / (metrics.densityDpi / 160f);
        return (int) dp;

    }

    /**
     * Hide the soft keyboard from screen for edit text only
     *
     * @param mContext
     */
    public static void hideSoftKeyBoard(Context mContext, View view) {
        try {

            final InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    // public static void hideSoftKeyboard(final Activity activity) {
    // try {
    // final InputMethodManager inputMethodManager = (InputMethodManager)
    // activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
    // if (inputMethodManager.isActive()) {
    // if (activity.getCurrentFocus() != null) {
    // inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(),
    // 0);
    // }
    // }
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }

    public static void openSoftKeyboard(final Activity activity, EditText editText) {
        try {
            // InputMethodManager inputMethodManager =
            // (InputMethodManager)
            // activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            // inputMethodManager.toggleSoftInputFromWindow(editText.getApplicationWindowToken(),
            // InputMethodManager.SHOW_FORCED, 0);

//            InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
//            inputMethodManager.toggleSoftInputFromWindow(editText.getApplicationWindowToken(),
//            InputMethodManager.SHOW_FORCED, 0);

            InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.toggleSoftInputFromWindow(editText.getApplicationWindowToken(), InputMethodManager.SHOW_FORCED, 0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void writeLog(final Context context, String detail) {
        if (true) {
            Log.i(context.getClass().getSimpleName(), detail);
        }

    }

    public static void hideKeyboardOutsideOfTouch(View view, final Context mContext) {

        // Set up touch listener for non-text box views to hide keyboard.
        if (!(view instanceof EditText)) {

            view.setOnTouchListener(new OnTouchListener() {

                public boolean onTouch(View v, MotionEvent event) {

                    Util.hideKeyboard(mContext);
                    return false;
                }

            });
        }

        // If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {

            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {

                View innerView = ((ViewGroup) view).getChildAt(i);

                hideKeyboardOutsideOfTouch(innerView, mContext);
            }
        }
    }

    public static void hideKeyboardOutsideOfTouchFragmentDialog(View view, final Context mContext) {

        // Set up touch listener for non-text box views to hide keyboard.
        if (!(view instanceof EditText)) {

            view.setOnTouchListener(new OnTouchListener() {

                public boolean onTouch(View v, MotionEvent event) {

                    hideKeyboardWithDialog(mContext);
                    return false;
                }

            });
        }

        // If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {

            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {

                View innerView = ((ViewGroup) view).getChildAt(i);

                hideKeyboardOutsideOfTouch(innerView, mContext);
            }
        }
    }


    public static void sendActionEventsTrackerforDialog(Tracker tracker, String category, String action, String label) {
        tracker.send(new HitBuilders.EventBuilder()
                .setCategory("" + category)
                .setLabel("" + label)
                .setAction("" + action)
                .build());
    }





    public static void gpsOn(final Context mContext)
    {
        LocationManager manager = (LocationManager) mContext.getSystemService( mContext.getApplicationContext().LOCATION_SERVICE );
        boolean isGPSEnabled = manager .isProviderEnabled(LocationManager.GPS_PROVIDER);

        Log.d("isGPSEnabled","isGPSEnabled=="+isGPSEnabled);

        if(!isGPSEnabled)
        {
            //Settings.Secure.putString(mContext.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED, "network,gps");

            //if gps is disabled
//            final Intent poke = new Intent();
//            poke.setClassName("com.android.settings", "com.android.settings.widget.SettingsAppWidgetProvider");
//            poke.addCategory(Intent.CATEGORY_ALTERNATIVE);
//            poke.setData(Uri.parse("3"));
//            mContext.sendBroadcast(poke);
        }
    }


}
