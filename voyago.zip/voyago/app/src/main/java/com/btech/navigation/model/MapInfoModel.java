package com.btech.navigation.model;

public class MapInfoModel {


    private String latlong;
    private String title;
    private String description;
    private String duratuin;
    private String distance;


    public MapInfoModel() {

    }

    public String getLatlong() {
        return latlong;
    }

    public void setLatlong(String latlong) {
        this.latlong = latlong;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDuratuin() {
        return duratuin;
    }

    public void setDuratuin(String duratuin) {
        this.duratuin = duratuin;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }


}
