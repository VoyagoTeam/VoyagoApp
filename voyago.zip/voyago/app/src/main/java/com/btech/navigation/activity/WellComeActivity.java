package com.btech.navigation.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.btech.navigation.NavigationApplication;
import com.kodeguy.qrbarreader.R;
import com.stephentuso.welcome.WelcomeScreenHelper;
import com.stephentuso.welcome.ui.WelcomeActivity;

public class WellComeActivity extends AppCompatActivity {

    WelcomeScreenHelper welcomeScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcomescreen);

        welcomeScreen = new WelcomeScreenHelper(this, MyWelcomeActivity.class);
        welcomeScreen.show(savedInstanceState);
        welcomeScreen.forceShow();



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d("onActivityResult","onActivityResult=="+requestCode+"==resultCode=="+resultCode);

        if (requestCode == WelcomeScreenHelper.DEFAULT_WELCOME_SCREEN_REQUEST)
        {
            String welcomeKey = data.getStringExtra(WelcomeActivity.WELCOME_SCREEN_KEY);

            if (resultCode == RESULT_OK) {


                NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isIntro), true);

               // Toast.makeText(getApplicationContext(), welcomeKey + " completed", Toast.LENGTH_SHORT).show();
                Intent i=new Intent(getApplicationContext(),WelComePoccedActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();

            } else {


                NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isIntro), true);


                //Toast.makeText(getApplicationContext(), welcomeKey + " canceled", Toast.LENGTH_SHORT).show();
                Intent i=new Intent(getApplicationContext(),WelComePoccedActivity.class);
                NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isIntro), true);
                //i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();

            }

        }
        else
        {

            NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isIntro), true);


            Intent i=new Intent(getApplicationContext(),WelComePoccedActivity.class);
            NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isIntro), true);
            //i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();

        }

    }




    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        welcomeScreen.onSaveInstanceState(outState);
    }
}
