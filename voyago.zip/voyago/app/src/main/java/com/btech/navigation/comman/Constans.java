package com.btech.navigation.comman;



/**
 * Created by on 30/05/15.
 */
public class Constans
{

    public static String service_login="login";
    public static String service_signup="signup";
    public static String service_forgotpassword="forgotpassword";

    // Google mao get placeses URL
    public final static String GOOGLE_GET_PLACE_URL = "https://maps.googleapis.com/maps/api/place/autocomplete/";
    public final static String GOOGLE_GET_LATLONG_URL = "https://maps.googleapis.com/maps/api/place/details/";





    public static class Config {
        public static final boolean DEVELOPER_MODE = false;
    }

    public static class Extra {
        public static final String FRAGMENT_INDEX = "com.nostra13.example.universalimageloader.FRAGMENT_INDEX";
        public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
    }
}
