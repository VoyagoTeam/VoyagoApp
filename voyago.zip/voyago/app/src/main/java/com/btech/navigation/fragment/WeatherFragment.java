package com.btech.navigation.fragment;

import android.app.Fragment;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.kodeguy.qrbarreader.R;
import com.btech.navigation.activity.GPSTracker;
import com.btech.navigation.activity.Weather;
import com.btech.navigation.adapter.WeatherAdapter;
import com.btech.navigation.comman.Util;
import com.btech.navigation.model.WeatherData;
import com.btech.navigation.webservice.APIManager;


import java.util.ArrayList;
import java.util.List;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;


public class WeatherFragment extends Fragment {

    private static final String TAG = "SPLASH";

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private Typeface weatherFont;
    private String place_location="";
    private ProgressBar spinner;

    TextView weather_report,place,weather_icon,country,icon_text;
    List myList ;
    String API_KEY="3043afb0cd9d116b49606f57bd4ac631"; //insert api key here
   /* old===  84da39766b39f49eb07556f42e7e996a*/
    //3043afb0cd9d116b49606f57bd4ac631
    private final static String PATH_TO_WEATHER_FONT = "fonts/weather.ttf";
    private ListView lv;
    View rootView;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {

         rootView = inflater.inflate(R.layout.activity_scrolling, null);


        spinner = (ProgressBar)rootView.findViewById(R.id.progressBar1);
        spinner.setVisibility(View.VISIBLE);

        weather_icon=(TextView)rootView.findViewById(R.id.weather_icon);

        country=(TextView)rootView.findViewById(R.id.country);
        weatherFont = Typeface.createFromAsset(getActivity().getAssets(), PATH_TO_WEATHER_FONT);
        weather_icon.setTypeface(weatherFont);





        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_id);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);



        weather_report = (TextView) rootView.findViewById(R.id.weather_report);
        place =(TextView)rootView.findViewById(R.id.place);

        GPSTracker gpsTracker = new GPSTracker(getActivity());

        if (gpsTracker.getIsGPSTrackingEnabled())
        {
            String stringLatitude = String.valueOf(gpsTracker.latitude);
            String stringLongitude = String.valueOf(gpsTracker.longitude);


            if (Util.isNetworkAvailable(getActivity()))
            {
                APIManager.getApiService().getWeatherInfo(stringLatitude,
                        stringLongitude,
                        "10",
                        API_KEY,
                        callback);


                String postalCode = gpsTracker.getPostalCode(getActivity());

                String addressLine = gpsTracker.getAddressLine(getActivity());
            }
            else
            {
                //Snackbar.make(rootView, "you are view weather of " + place_location, Snackbar.LENGTH_LONG)
                //        .setAction("Action", null).show();

                Toast.makeText(getActivity(),"Please check your internet connection.",Toast.LENGTH_LONG).show();
            }



        }
        else
        {

            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gpsTracker.showSettingsAlert();
        }





       // Toolbar toolbar = (Toolbar) rootView.findViewById(R.id.toolbar);
       //((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);


        // Initializing Toolbar and setting it as the actionbar
        Toolbar toolbar = (Toolbar) rootView.findViewById(R.id.toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        //((AppCompatActivity) getActivity()).setSupportActionBar(((MainActivity) getActivity()).getToolbar());
        final ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        TextView mTitle = (TextView) toolbar.findViewById(R.id.actionbar_tvTitle);
        mTitle.setVisibility(View.VISIBLE);
        mTitle.setText("YOUR WEATHER");
        actionBar.show();


        if (actionBar != null) {

            actionBar.setHomeAsUpIndicator(R.drawable.back_btn);
            actionBar.setTitle("");
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setHomeButtonEnabled(true);
        }




        FloatingActionButton fab = (FloatingActionButton) rootView.findViewById(R.id.fab);




        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "you are view weather of " + place_location, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();


            }
        });



        return  rootView;

    }




    private Callback<WeatherData> callback = new Callback<WeatherData>() {
        public List<Weather> weathers;
        @Override
        public void success (WeatherData response, Response response2) {


            weather_report.setText(response.getList().get(0).getWeather().get(0).getDescription());
            place.setText(response.getCity().getName());
            country.setText(response.getCity().getCountry());
            place_location =response.getCity().getName();


            Log.w("icon", response.getList().get(0).getWeather().get(0).getIcon());
            switch (response.getList().get(0).getWeather().get(0).getIcon()){
                case "01d":
                    weather_icon.setText(R.string.wi_day_sunny);
                    break;
                case "02d":
                    weather_icon.setText(R.string.wi_cloudy_gusts);
                    break;
                case "03d":
                    weather_icon.setText(R.string.wi_cloud_down);
                    break;
                case "04d":
                    weather_icon.setText(R.string.wi_cloudy);
                    break;
                case "04n":
                    weather_icon.setText(R.string.wi_night_cloudy);
                    break;
                case "10d":
                    weather_icon.setText(R.string.wi_day_rain_mix);
                    break;
                case "11d":
                    weather_icon.setText(R.string.wi_day_thunderstorm);
                    break;
                case "13d":
                    weather_icon.setText(R.string.wi_day_snow);
                    break;
                case "01n":
                    weather_icon.setText(R.string.wi_night_clear);
                    break;
                case "02n":
                    weather_icon.setText(R.string.wi_night_cloudy);
                    break;
                case "03n":
                    weather_icon.setText(R.string.wi_night_cloudy_gusts);
                    break;
                case "10n":
                    weather_icon.setText(R.string.wi_night_cloudy_gusts);
                    break;
                case "11n":
                    weather_icon.setText(R.string.wi_night_rain);
                    break;
                case "13n":
                    weather_icon.setText(R.string.wi_night_snow);
                    break;



            }
            String[]humidity = new String[10];
            String[]rain_description=new String[10];
            String[]icon=new String[10];
            String[]time=new String[10];
            weathers = new ArrayList<>();
            for (int i=0; i<response.getList().size();i++){
                humidity[i] = String.valueOf(response.getList().get(i).getMain().getHumidity());
                rain_description[i] = String.valueOf(response.getList().get(i).getWeather().get(0).getDescription());
                icon[i] = String.valueOf(response.getList().get(i).getWeather().get(0).getIcon());
                time[i] = String.valueOf(response.getList().get(i).getDt());

                Log.w("humidity",humidity[i]);
                Log.w("rain_description",rain_description[i]);
                Log.w("icon",icon[i]);
                Log.w("time",time[i]);

                weathers.add(new Weather(String.valueOf(response.getList().get(i).getWeather().get(0).getIcon()), String.valueOf(response.getList().get(i).getMain().getHumidity()), String.valueOf(response.getList().get(i).getWeather().get(0).getDescription()), String.valueOf(response.getList().get(i).getDt())));

            }
            mAdapter = new WeatherAdapter(weathers,weatherFont);
            mRecyclerView.setAdapter(mAdapter);

            spinner.setVisibility(View.GONE);


        }

        @Override
        public void failure (RetrofitError error) {

            place.setText("Unable to retrieve data");

            spinner.setVisibility(View.GONE);


           // Log.d("", "failure", error);

        }
    };


}
