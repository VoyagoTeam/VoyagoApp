package com.btech.navigation.model;

/**
 * Created by rohit on 10/15/15.
 */
public class Sys {

    private Integer population;

    /**
     *
     * @return
     * The population
     */
    public Integer getPopulation() {
        return population;
    }

    /**
     *
     * @param population
     * The population
     */
    public void setPopulation(Integer population) {
        this.population = population;
    }

}
