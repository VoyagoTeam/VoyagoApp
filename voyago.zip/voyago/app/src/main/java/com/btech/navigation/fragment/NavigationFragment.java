package com.btech.navigation.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.GeomagneticField;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kodeguy.qrbarreader.R;
import com.btech.navigation.activity.BaseActivity;
import com.btech.navigation.adapter.GooglePlacesAutocompleteAdapterNew;
import com.btech.navigation.adapter.MapInstractionListAdapter;
import com.btech.navigation.comman.GoogleDirection;
import com.btech.navigation.comman.IconGenerator;
import com.btech.navigation.comman.Util;
import com.btech.navigation.model.MapInfoModel;
import com.btech.navigation.webservice.WSgetLatLongGoogleApi;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sothree.slidinguppanel.SlidingUpPanelLayout;
import com.uber.sdk.android.rides.RequestButton;
import com.uber.sdk.android.rides.RideParameters;

import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

import static com.google.android.gms.maps.CameraUpdateFactory.newCameraPosition;
import static com.google.android.gms.maps.CameraUpdateFactory.newLatLng;

/**
 * *************************************************************************
 *
 * @ClassdName:SharingRootPathFragment
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This class is use to connect with companion then Root path starting Trip to end trip drow path.
 * <p/>
 * *************************************************************************
 */

public class NavigationFragment extends Fragment implements OnClickListener {


    private RelativeLayout rlListToMap;
    private LinearLayout rlKm;
    private LinearLayout llDragView;
    private LinearLayout llFromTo;
    private TextView tvInfo;
    private TextView timeKm;
    private TextView timeKm1;
    private RequestButton rbUber;
    private FrameLayout llCallUber;
    private TextView tvFromLocation;
    private TextView tvToLocation;
    private ImageView ivLeftPanel;
    private ImageView ivZoomOut;
    private ImageView ivZoomIn;
    private ListView lvMapInstractionInfoList;
    private SlidingUpPanelLayout mLayout;
    private Bundle SavedInstanceState;

    private String startingTripLocation;
    private String endingTripLocation;

    private Boolean checkMapOrList = false;
    private Boolean isAnimateMap = true;
    private GoogleMap googleMap;
    private MapView mapView;
    private ProgressDialog progress;
    private GoogleDirection gd;
    private List<LatLng> listLatLong;
    private ArrayList<MapInfoModel> mapInfoModelList;
    private View overlay;
    private Document mDoc;
    private LatLng start;
    private LatLng end;
    private GeomagneticField geoField;
    private Marker mPositionMarker;
    private Location preLocation = null;
    private Handler handler;
    private TextToSpeech textToSpeech;
    private boolean IsSafeDriving;


    //declaration String
    private String location = "";
    private String title = "";
    private String fromLocatin;
    private String toLocation;
    private String fromAdd;
    private String toAdd;

    //Declaration Dialog View
    private Dialog dialogExplolerItem;
    private GetLocationAddressAsync mGetLocationAddressAsync;

    //private BoomMenuButton boomMenuButton;
    private FloatingActionButton fb_poi;
    private Handler rotator;
    private Runnable runnable;
    private boolean isFromTo;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_navigation, container, false);

        if (!isGooglePlayServicesAvailable()) {
            Toast.makeText(getActivity(), "no_map_support", Toast.LENGTH_LONG).show();
            getActivity().finish();
        }

        initializeComponent(view);

        // AdBuddiz.setPublisherKey("b59d68a3-e7c6-4bda-9aa7-41c67875c284");
        // AdBuddiz.cacheAds(getActivity());
        // AdBuddiz.showAd(getActivity());
        //AdBuddiz.RewardedVideo.fetch(getActivity());
        return view;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SavedInstanceState = savedInstanceState;

    }

    @SuppressLint("MissingPermission")
    protected void initializeComponent(View v) {

        mapInfoModelList = new ArrayList<MapInfoModel>();

        getActivity().setResult(Activity.RESULT_CANCELED);
        handler = new Handler();

        rlListToMap = (RelativeLayout) v.findViewById(R.id.fargment_sharing_root_path_rlListToMap);
        rlKm = (LinearLayout) v.findViewById(R.id.rlKm);
        llDragView = (LinearLayout) v.findViewById(R.id.dragView);
        llFromTo = (LinearLayout) v.findViewById(R.id.llFromTo);
        mapView = (MapView) v.findViewById(R.id.mapview);
        mapView.onCreate(SavedInstanceState);

        tvInfo = (TextView) v.findViewById(R.id.fargment_sharing_root_path_tvInfo);
        timeKm = (TextView) v.findViewById(R.id.tvKmTime);
        timeKm1 = (TextView) v.findViewById(R.id.tvKmTime1);

        llCallUber = (FrameLayout) v.findViewById(R.id.llCallUber);
        tvFromLocation = (TextView) v.findViewById(R.id.tvFromLocation);
        tvToLocation = (TextView) v.findViewById(R.id.tvToLocation);
        ivLeftPanel = (ImageView) v.findViewById(R.id.fargment_sharing_root_path_ivLeftPanel);
        lvMapInstractionInfoList = (ListView) v.findViewById(R.id.fargment_sharing_root_path_lvMapInstractionInfo);
        mLayout = (SlidingUpPanelLayout) v.findViewById(R.id.sliding_layout);
        fb_poi = (FloatingActionButton) v.findViewById(R.id.fragment_poi_fab);
        fb_poi.setOnClickListener(this);
        tvFromLocation.setOnClickListener(this);
        tvToLocation.setOnClickListener(this);

        ivZoomOut = (ImageView) v.findViewById(R.id.zoomOut);
        ivZoomIn = (ImageView) v.findViewById(R.id.zoomIn);
        ivZoomOut.setOnClickListener(this);
        ivZoomIn.setOnClickListener(this);
        llCallUber.setOnClickListener(this);

        googleMap = mapView.getMap();
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        googleMap.setMyLocationEnabled(true);
        googleMap.setTrafficEnabled(true);
        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        googleMap.getUiSettings().setZoomControlsEnabled(false);
        MapsInitializer.initialize(this.getActivity());

        gd = new GoogleDirection(getActivity());
        panelListener();
        updateUI();


    }

    private void updateUI() {

        LatLng mLatLng;

        if (((BaseActivity) getActivity()).getCurrentLocation() != null) {

            double lat = Double.parseDouble(((BaseActivity) getActivity()).getCurrentLocation().split(",")[0]);
            double lng = Double.parseDouble(((BaseActivity) getActivity()).getCurrentLocation().split(",")[1]);
            mLatLng = new LatLng(lat, lng);
            //CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(mLatLng, 10);
            //map.animateCamera(cameraUpdate);

            //Goole Map 3d View
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(lat, lng)) // Sets the center of the map to
                    .zoom(20)                   // Sets the zoom
                    .tilt(90)    // Sets the tilt of the camera to 30 degrees
                    .build();    // Creates a CameraPosition from the builder
            googleMap.animateCamera(newCameraPosition(
                    cameraPosition));

            googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
            googleMap.getUiSettings().setZoomControlsEnabled(false);
            MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_red));
            markerOptions.title("My Location");
            googleMap.addMarker(markerOptions.position(mLatLng));

        } else {
            rotator = new Handler();
            runnable = new Runnable() {
                public void run() {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    updateUI();

                }
            };

            rotator.postDelayed(runnable, 3000);
        }
    }

    private Runnable mRunnebleNew = new Runnable() {
        public void run() {
            Log.e("", "call Handler ");

            if (((BaseActivity) getActivity()).getCurrentLocation() != null) {

                String mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation().trim();
                Double lat = Double.valueOf(mCurrentLocation.split(",")[0]); // getlatitute
                Double lng = Double.valueOf(mCurrentLocation.split(",")[1]); // getLongitute


                ArrayList<Float> nearstArr = new ArrayList<Float>();

                for (int i = 0; i < gd.startLocation.size(); i++) {

                    Float nearsValue = distance(new LatLng(lat, lng), new LatLng(gd.startLocation.get(i).latitude, gd.startLocation.get(i).longitude));
                    nearstArr.add(nearsValue);

                }


                if (nearstArr.size() > 0) {
                    int minIndex = nearstArr.indexOf(Collections.min(nearstArr));

                    Log.e("", "minIndex " + minIndex);


                    if (gd.startLocationInstraction.get(minIndex).contains("left")) {
                        ivLeftPanel.setBackgroundResource(R.drawable.turn_left);

                    } else if (gd.startLocationInstraction.get(minIndex).contains("right")) {
                        ivLeftPanel.setBackgroundResource(R.drawable.turn_right);
                    } else {
                        ivLeftPanel.setBackgroundResource(R.drawable.turn_streat_arro);
                    }

                    tvInfo.setText("" + removeTags(gd.startLocationInstraction.get(minIndex)));


                    // Log.d("","Minimum distance:"+nearstArr.get(minIndex));

                    //check nearst location Distance > 20 Ml then textToPich

                    if (nearstArr.get(minIndex) < 30) {
                        textToSpeech.speak(removeTags(gd.startLocationInstraction.get(minIndex)).toString(), TextToSpeech.QUEUE_FLUSH, null);
                    }


                }

            }

            handler.postDelayed(mRunnebleNew, 5000);
        }
    };


    public static <T extends Comparable<T>> int findMinIndex(final List<T> xs) {
        int minIndex;
        if (xs.isEmpty()) {
            minIndex = -1;
        } else {
            final ListIterator<T> itr = xs.listIterator();
            T min = itr.next(); // first element as the current minimum
            minIndex = itr.previousIndex();
            while (itr.hasNext()) {
                final T curr = itr.next();
                if (curr.compareTo(min) < 0) {
                    min = curr;
                    minIndex = itr.previousIndex();
                }
            }
        }
        return minIndex;
    }

    public float distance(LatLng current, LatLng last) {
        if (last == null)
            return 0;
        Location cL = new Location("");
        cL.setLatitude(current.latitude);
        cL.setLongitude(current.longitude);

        Location lL = new Location("");
        lL.setLatitude(last.latitude);
        lL.setLongitude(last.longitude);

        return lL.distanceTo(cL);
    }


    public String removeTags(String in) {
        int index = 0;
        int index2 = 0;
        while (index != -1) {
            index = in.indexOf("<");
            index2 = in.indexOf(">", index);
            if (index != -1 && index2 != -1) {
                in = in.substring(0, index).concat(in.substring(index2 + 1, in.length()));
            }
        }

        in = in.replace("&nbsp;", " ");
        in = in.replace("(", "");
        in = in.replace(")", "");

        return in;
    }

    private void addIcon(IconGenerator iconFactory, String text, LatLng position) {
        MarkerOptions markerOptions = new MarkerOptions().
                icon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon(text))).
                position(position).
                anchor(iconFactory.getAnchorU(), iconFactory.getAnchorV());

        googleMap.addMarker(markerOptions);
    }

    private void DrowPath() {
        Double Sourcestr = Double.valueOf(startingTripLocation.split(",")[0]);
        Double Sourceend = Double.valueOf(startingTripLocation.split(",")[1]);

        Double Deststr = Double.valueOf(endingTripLocation.split(",")[0]);
        Double Destend = Double.valueOf(endingTripLocation.split(",")[1]);

        start = new LatLng(Sourcestr, Sourceend);
        end = new LatLng(Deststr, Destend);

        gd.setLogging(true);
        gd.request(start, end, GoogleDirection.MODE_DRIVING);


        googleMap.moveCamera(newLatLng(new LatLng(Sourcestr, Sourceend)));
        //googleMap.animateCamera(CameraUpdateFactory.zoomTo(30));

        //Goole Map 3d View
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(start) // Sets the center of the map to
                .zoom(20)                   // Sets the zoom
                .bearing(getBearing(start, end)) // Sets the orientation of the camera to east
                .tilt(90)    // Sets the tilt of the camera to 30 degrees
                .build();    // Creates a CameraPosition from the builder
        googleMap.animateCamera(newCameraPosition(
                cameraPosition));

        googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        googleMap.getUiSettings().setZoomControlsEnabled(false);

    }

    private float getBearing(LatLng begin, LatLng end) {
        double lat = Math.abs(begin.latitude - end.latitude);
        double lng = Math.abs(begin.longitude - end.longitude);
        if (begin.latitude < end.latitude && begin.longitude < end.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)));
        else if (begin.latitude >= end.latitude && begin.longitude < end.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 90);
        else if (begin.latitude >= end.latitude && begin.longitude >= end.longitude)
            return (float) (Math.toDegrees(Math.atan(lng / lat)) + 180);
        else if (begin.latitude < end.latitude && begin.longitude >= end.longitude)
            return (float) ((90 - Math.toDegrees(Math.atan(lng / lat))) + 270);
        return -1;
    }

    private Runnable mRunneble = new Runnable() {
        public void run() {
            Log.e("", "call Handle ");

            if (((BaseActivity) getActivity()).getCurrentLocation() != null) {


                String mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation().trim();

                Log.e("", "mCurrentLocation:-" + mCurrentLocation);

                Double lat = Double.valueOf(mCurrentLocation.split(",")[0]); // getlatitute
                Double lng = Double.valueOf(mCurrentLocation.split(",")[1]); // getLongitute

                Log.e("", "latitude:-" + lat + "longitude:-" + lng);
                LatLng crntLocationLatLngNew = new LatLng(lat, lng);


                Double Deststr = Double.valueOf(endingTripLocation.split(",")[0]);
                Double Destend = Double.valueOf(endingTripLocation.split(",")[1]);

                LatLng crntLocationLatLngEnd = new LatLng(Deststr, Destend);

                Location location = ((BaseActivity) getActivity()).getmCurrentLocation();
                //gd.clickMe(googleMap, crntLocationLatLngNew, new LatLng(Deststr, Destend));


                if (location == null)
                    return;


                if (location != null) {
                    if (preLocation != null) {
                        Log.e("", "location==" + location.getLatitude() + "," + location.getLongitude());
                        Log.e("", "location==Pre==" + preLocation.getLatitude() + "," + preLocation.getLongitude());

                        if (distance(location.getLatitude(), location.getLongitude(), preLocation.getLatitude(), preLocation.getLongitude()) > 0) {

                            Log.e("", "location==distance if greate" + preLocation.getLatitude());
                            //float bearing = preLocation.bearingTo(location) ;

                            double bearing = GetBearing(crntLocationLatLngNew, new LatLng(preLocation.getLatitude(), preLocation.getLongitude()));

                            Log.e("", "location==distance bearing" + bearing);

                            preLocation = location;
                            animateMarkerNew(mPositionMarker, Float.parseFloat(new String(String.valueOf(bearing))), location);
                            googleMap.animateCamera(newLatLng(new LatLng(location.getLatitude(), location.getLongitude())));

                        }
                    } else {
                        preLocation = location;

                        if (mPositionMarker == null) {

                            float bearing = preLocation.bearingTo(location);
                            mPositionMarker = googleMap.addMarker(new MarkerOptions()
                                    .flat(true)
                                    .icon(BitmapDescriptorFactory
                                            .fromResource(R.drawable.pin_dyrct_blue))
                                    .anchor(0.5f, 0.5f)
                                    .rotation(bearing)
                                    .flat(true)
                                    .position(
                                            new LatLng(location.getLatitude(), location
                                                    .getLongitude())));
                        }

                        // animateMarker(mPositionMarker, location); // Helper method for smooth
                        googleMap.animateCamera(newLatLng(new LatLng(location.getLatitude(), location.getLongitude())));


                    }

                    handler.postDelayed(mRunneble, 5000);
                }
            }
        }
    };

    private final double degreesPerRadian = 180.0 / Math.PI;

    private double GetBearing(LatLng from, LatLng to) {
        double lat1 = from.latitude * Math.PI / 180.0;
        double lon1 = from.longitude * Math.PI / 180.0;
        double lat2 = to.latitude * Math.PI / 180.0;
        double lon2 = to.longitude * Math.PI / 180.0;

        // Compute the angle.
        double angle = -Math.atan2(Math.sin(lon1 - lon2) * Math.cos(lat2), Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(lon1 - lon2));

        if (angle < 0.0)
            angle += Math.PI * 2.0;

        // And convert result to degrees.
        angle = angle * degreesPerRadian;

        return angle;
    }

    /**
     * calculates the distance between two locations in MILES
     */
    private double distance(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 3958.75; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double dist = earthRadius * c;

        // Log.d("", "dist:-" + dist);

        return dist; // output distance, in MILES
    }

    public void animateMarkerNew(final Marker marker, final float bearing, final Location location) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final long duration = 500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);


                marker.setPosition(new LatLng(location.getLatitude(), location.getLongitude()));

                // Log.d("","bearing:"+bearing);

                marker.setRotation(bearing);
                marker.setAnchor(0.5f, 0.5f);

                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }


    public void animateMarker(final Marker marker, final Location location, final float bearing) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        final LatLng startLatLng = marker.getPosition();
        final double startRotation = marker.getRotation();
        final long duration = 500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);

                double lng = t * location.getLongitude() + (1 - t)
                        * startLatLng.longitude;
                double lat = t * location.getLatitude() + (1 - t)
                        * startLatLng.latitude;

                float rotation = (float) (t * location.getBearing() + (1 - t)
                        * startRotation);

                marker.setPosition(new LatLng(lat, lng));
                marker.setRotation(rotation);

                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                }
            }
        });
    }


    /**
     * This Method use check GooglePlay service Avalable or Not
     */
    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity());
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            GooglePlayServicesUtil.getErrorDialog(status, getActivity(), 0).show();
            return false;
        }
    }


    private void callUber() {

        if (startingTripLocation != null && !startingTripLocation.equalsIgnoreCase("")) {

            final String clientId = getString(R.string.uber_client_id);
            final String productId = getString(R.string.uber_product_id);

            if (clientId == null) {
                throw new IllegalStateException("Client ID required to use RequestButton.");
            }

            rbUber.setClientId(clientId);

            final Float PICKUP_LAT = Float.valueOf(startingTripLocation.split(",")[0]);
            final Float PICKUP_LONG = Float.valueOf(startingTripLocation.split(",")[1]);

            final Float DROPOFF_LAT = Float.valueOf(endingTripLocation.split(",")[0]);
            final Float DROPOFF_LONG = Float.valueOf(endingTripLocation.split(",")[1]);

            final String PICKUP_NICK = "";
            final String DROPOFF_NICK = "";

            RideParameters rideParameters = new RideParameters.Builder()
                    .setProductId(productId)
                    .setPickupLocation(PICKUP_LAT, PICKUP_LONG, PICKUP_NICK, fromAdd)
                    .setDropoffLocation(DROPOFF_LAT, DROPOFF_LONG, DROPOFF_NICK, toAdd)
                    .build();

            rbUber.setRideParameters(rideParameters);

        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.llCallUber:

                callUber();
                break;

            case R.id.fragment_poi_fab:

                //AdBuddiz.showAd(getActivity());
                //AdBuddiz.RewardedVideo.show(getActivity());

               /* Bundle bundle = new Bundle();
                DialogSelectDirection mDialogSelectCategory = new DialogSelectDirection();
                mDialogSelectCategory.setTargetFragment(NavigationFragment.this, 99);
                mDialogSelectCategory.show(getFragmentManager(), "");*/



                if (llFromTo.getVisibility() == View.GONE) {
                    viewSlideDown();
                } else {
                    viewSlideUp();
                }

                break;

            case R.id.tvFromLocation:
                isFromTo = true;
                /*DialogSelectLocation mDialogSelectCategory = new DialogSelectLocation();
                mDialogSelectCategory.setTargetFragment(NavigationFragment.this, 99);
                mDialogSelectCategory.show(getFragmentManager(), "");*/

                openExplorerDailog();

                break;

            case R.id.tvToLocation:
                isFromTo = false;
               /* DialogSelectLocation mDialogSelect = new DialogSelectLocation();
                mDialogSelect.setTargetFragment(NavigationFragment.this, 99);
                mDialogSelect.show(getFragmentManager(), "");*/

                openExplorerDailog();

                break;

            case R.id.zoomOut:
                googleMap.animateCamera(CameraUpdateFactory.zoomIn());
                break;


            case R.id.zoomIn:
                googleMap.animateCamera(CameraUpdateFactory.zoomOut());
                break;


            default:
                break;
        }

    }


    private void viewSlideDown() {

        llFromTo.setVisibility(View.VISIBLE);
        TranslateAnimation anim = new TranslateAnimation(0, 0, -llFromTo.getHeight(), 0);
        anim.setDuration(500);
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        llFromTo.startAnimation(anim);


    }

    private void viewSlideUp() {


        TranslateAnimation anim = new TranslateAnimation(0, 0, 0, -llFromTo.getHeight());
        anim.setDuration(500);
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                llFromTo.setVisibility(View.GONE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        llFromTo.startAnimation(anim);

    }


    private void openExplorerDailog() {

        dialogExplolerItem = new Dialog(getActivity(), R.style.CustomDialogSerach2);
        dialogExplolerItem.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        dialogExplolerItem.setContentView(R.layout.dialog_select_location);
        final AutoCompleteTextView tvSearch;
        ImageView ivClose = (ImageView) dialogExplolerItem.findViewById(R.id.activity_mapcurrentLocation_ivEndCloseSearch);


        tvSearch = (AutoCompleteTextView) dialogExplolerItem.findViewById(R.id.tvSearch);
        Util.openSoftKeyboard(getActivity(), tvSearch);


        tvSearch.setAdapter(new GooglePlacesAutocompleteAdapterNew(getActivity()));
        tvSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {


                Util.hideSoftKeyBoard(getActivity(), tvSearch);
                Util.hideKeyboardWithDialog(getActivity());
                String startLocation = (String) adapterView.getItemAtPosition(position);
                // Log.d("startLocation","startLocation=="+startLocation);

                if (startLocation.split("===")[1].equalsIgnoreCase("My Location")) {
                    if (isFromTo) {
                        fromLocatin = ((BaseActivity) getActivity()).getCurrentLocation();
                        fromAdd = "My Location";
                        tvFromLocation.setText("" + fromAdd);


                        if (toLocation != null && !toLocation.equalsIgnoreCase("")) {
                            rlListToMap.setVisibility(View.VISIBLE);
                            llDragView.setVisibility(View.VISIBLE);
                            rlKm.setVisibility(View.VISIBLE);
                            setDirection(fromAdd, toAdd, fromLocatin, toLocation);
                        }
                    } else {
                        toLocation = ((BaseActivity) getActivity()).getCurrentLocation();
                        toAdd = "My Location";
                        ;
                        tvToLocation.setText("" + toAdd);


                        if (fromLocatin != null && !fromLocatin.equalsIgnoreCase("")) {
                            rlListToMap.setVisibility(View.VISIBLE);
                            llDragView.setVisibility(View.VISIBLE);
                            rlKm.setVisibility(View.VISIBLE);
                            setDirection(fromAdd, toAdd, fromLocatin, toLocation);
                        }


                    }

                    dialogExplolerItem.dismiss();

                } else {
                    addressToLatlong(startLocation);
                }


            }
        });

        ivClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSearch.setText("");
            }
        });

        dialogExplolerItem.setCanceledOnTouchOutside(true);
        //dialogExplolerItem.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialogExplolerItem.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialogExplolerItem.show();

    }


    private void addressToLatlong(String reference) {

        if (mGetLocationAddressAsync != null && mGetLocationAddressAsync.getStatus() == AsyncTask.Status.PENDING) {
            mGetLocationAddressAsync.execute();
        } else if (mGetLocationAddressAsync == null || mGetLocationAddressAsync.getStatus() == AsyncTask.Status.FINISHED) {
            mGetLocationAddressAsync = new GetLocationAddressAsync(reference, getActivity());
            mGetLocationAddressAsync.execute();
        }


    }

    private class GetLocationAddressAsync extends AsyncTask<String, Void, String> {

        // boolean duplicateResponse;
        String reference;
        String address;
        String latlong;

        WSgetLatLongGoogleApi mWSgetLatLongGoogleApi;

        public GetLocationAddressAsync(String reference, final Context context) {
            this.reference = reference.split("==")[1];
            this.address = reference.split("==")[0];

        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {


            mWSgetLatLongGoogleApi = new WSgetLatLongGoogleApi(getActivity());
            latlong = mWSgetLatLongGoogleApi.executeService(reference);
            return null;

        }

        @Override
        protected void onPostExecute(String result) {

            double lat = Double.parseDouble(latlong.split(",")[0]);
            double lng = Double.parseDouble(latlong.split(",")[1]);
            String startLatLong = String.valueOf(lat + "," + lng);

            dialogExplolerItem.dismiss();

            if (isFromTo) {
                fromLocatin = startLatLong;
                fromAdd = address;
                tvFromLocation.setText("" + fromAdd);

                if (toLocation != null && !toLocation.equalsIgnoreCase("")) {

                    rlListToMap.setVisibility(View.VISIBLE);
                    llDragView.setVisibility(View.VISIBLE);
                    rlKm.setVisibility(View.VISIBLE);
                    setDirection(fromAdd, toAdd, fromLocatin, toLocation);

                }
            } else {
                toLocation = startLatLong;
                toAdd = address;
                ;
                tvToLocation.setText("" + toAdd);


                if (fromLocatin != null && !fromLocatin.equalsIgnoreCase("")) {

                    rlListToMap.setVisibility(View.VISIBLE);
                    llDragView.setVisibility(View.VISIBLE);
                    rlKm.setVisibility(View.VISIBLE);
                    setDirection(fromAdd, toAdd, fromLocatin, toLocation);

                }
            }


        }


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        /****************************************************************************
         *
         * @purpose:Return on Bundle public And private Address,location,city,state,country,zipcode
         *
         ***************************************************************************/

        if (requestCode == 99) {
            Bundle bundle = data.getExtras();
            String startAdd = bundle.getString("startLocation");
            String startLatLong = bundle.getString("startLatLong");

            // Log.d("requestCode","startAdd==="+startAdd+"===startLatLong==="+startLatLong+"==getCurrentLocation=="+((BaseActivity) getActivity()).getCurrentLocation());

            if (startAdd.equalsIgnoreCase("My Location")) {
                if (isFromTo) {
                    fromLocatin = ((BaseActivity) getActivity()).getCurrentLocation();
                    fromAdd = "My Location";
                    tvFromLocation.setText("" + fromAdd);
                } else {
                    toLocation = ((BaseActivity) getActivity()).getCurrentLocation();
                    ;
                    toAdd = "My Location";
                    tvToLocation.setText("" + toAdd);

                    rlListToMap.setVisibility(View.VISIBLE);
                    llDragView.setVisibility(View.VISIBLE);
                    rlKm.setVisibility(View.VISIBLE);
                    setDirection(fromAdd, toAdd, fromLocatin, toLocation);
                }
            } else {
                // Log.d("NavigationView","startAdd=="+startAdd);
                //Log.d("NavigationView","startLatLong=="+startLatLong);


                if (isFromTo) {
                    fromLocatin = startLatLong;
                    fromAdd = startAdd;
                    tvFromLocation.setText("" + fromAdd);
                } else {
                    toLocation = startLatLong;
                    toAdd = startAdd;
                    tvToLocation.setText("" + toAdd);

                    rlListToMap.setVisibility(View.VISIBLE);
                    llDragView.setVisibility(View.VISIBLE);
                    rlKm.setVisibility(View.VISIBLE);
                    setDirection(fromAdd, toAdd, fromLocatin, toLocation);
                }
            }
        }


    }

    private void setDirection(final String startAdd, final String endAdd, String startLatLong, String endLatLong) {

        startingTripLocation = startLatLong;
        endingTripLocation = endLatLong;
        title = "Test";


        if (startingTripLocation.isEmpty() && endingTripLocation.isEmpty()) {
            Toast.makeText(getActivity(), "Please select direction.", Toast.LENGTH_LONG).show();
        } else {

            progress = new ProgressDialog(getActivity());
            progress.show();
            progress.setMessage("Please wait...");
            progress.setCancelable(false);


            //callWebService();


            gd.setOnDirectionResponseListener(new GoogleDirection.OnDirectionResponseListener() {
                public void onResponse(String status, Document doc, GoogleDirection gd) {


                    if (progress != null && progress.isShowing()) {
                        progress.dismiss();
                    }

                    if (status.equalsIgnoreCase("OK")) {

                        mDoc = doc;
                        googleMap.addPolyline(gd.getPolyline(doc, 3, Color.BLUE));
                        googleMap.addMarker(new MarkerOptions().position(start)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_red)).title(startAdd));

                        googleMap.addMarker(new MarkerOptions().position(end)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin_dyrct_green)).title(endAdd));


                        //gd.animateDirection(googleMap, gd.getDirection(mDoc), GoogleDirection.SPEED_VERY_FAST
                        //		, true, false, true, true, new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.car)), false, true, null);


                        gd.getDirection(mDoc);


                        timeKm.setText("" + gd.getTotalDurationText(mDoc));
                        timeKm1.setText("" + gd.getTotalDistanceText(mDoc));

                        // Log.d("", "startLocation" + gd.startLocation.size());
                        // Log.d("", "startLocationInstraction" + gd.startLocationInstraction.size());

                        if (gd.startLocation.size() > 0) {

                            for (int i = 0; i < gd.startLocation.size(); i++) {

                                MapInfoModel mapModel = new MapInfoModel();
                                String turnInfo = "";
                                String turnInfoDest = "";

                                if (gd.startLocationInstraction.get(i).contains("left")) {
                                    turnInfo = "left";

                                } else if (gd.startLocationInstraction.get(i).contains("right")) {
                                    turnInfo = "right";
                                } else {
                                    turnInfo = "continue";
                                }

                                turnInfoDest = removeTags(gd.startLocationInstraction.get(i));
                                //timeKm.setText("" + removeTags(gd.startLocationInstraction.get(0)));


                                // Log.d("", "turnInfo-" + turnInfo + "==turnInfoDest==" + turnInfoDest);

                                mapModel.setTitle(turnInfo);
                                mapModel.setDescription(turnInfoDest);
                                mapInfoModelList.add(mapModel);

                                IconGenerator iconFactory = new IconGenerator(getActivity());
                                iconFactory.setRotation(90);
                                iconFactory.setContentRotation(-90);
                                iconFactory.setStyle(IconGenerator.STYLE_PURPLE);
                                addIcon(iconFactory, turnInfoDest, new LatLng(gd.startLocation.get(i).latitude, gd.startLocation.get(i).longitude));

                            }

                            MapInstractionListAdapter mMapInfoListAdapter = new MapInstractionListAdapter(getActivity(), mapInfoModelList);
                            lvMapInstractionInfoList.setAdapter(mMapInfoListAdapter);
                            mMapInfoListAdapter.notifyDataSetChanged();

                            //call Handler
                            handler.postDelayed(mRunnebleNew, 5000);

                            //handler.postDelayed(mRunneble,5000);

                        }
                    } else {
                        Toast.makeText(getActivity(), "No Rout Found.", Toast.LENGTH_LONG).show();
                    }
                }
            });

            DrowPath();


            textToSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status != TextToSpeech.ERROR) {
                        textToSpeech.setLanguage(Locale.UK);
                    }
                }
            });


            Animation animation1 = AnimationUtils.loadAnimation(getActivity(), R.anim.blink);
            ivLeftPanel.startAnimation(animation1);

        }


    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (handler != null) {
            handler.removeCallbacks(mRunnebleNew);
        }

        if (rotator != null) {
            rotator.removeCallbacks(runnable);
        }
    }

    @Override
    public void onDestroy() {

        super.onDestroy();
        mapView.onDestroy();
        //AdBuddiz.onDestroy(); // to minimize memory footprint

        if (progress != null && progress.isShowing()) {
            progress.dismiss();
        }


        if (handler != null) {
            handler.removeCallbacks(mRunnebleNew);
        }


        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }

    }


    public void onPause() {
        super.onPause();
        gd.cancelAnimated();

        if (handler != null) {
            handler.removeCallbacks(mRunnebleNew);
        }


        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }


    public String deDup(String s) {
        return new LinkedHashSet<String>(Arrays.asList(s.split("-"))).toString().replaceAll("(^\\[|\\]$)", "").replace(", ", "-");
    }


    /**
     * this method call setPanelSlidelistener method to listen open and close of slide panel
     */
    public void panelListener() {

        mLayout.setPanelSlideListener(new SlidingUpPanelLayout.PanelSlideListener() {

            // During the transition of expand and collapse onPanelSlide function will be called.
            @Override
            public void onPanelSlide(View panel, float slideOffset) {
                //Log.e(TAG, "onPanelSlide, offset " + slideOffset);
            }

            // This method will be call after slide up layout
            @Override
            public void onPanelExpanded(View panel) {
                //Log.e(TAG, "onPanelExpanded");

            }

            // This method will be call after slide down layout.
            @Override
            public void onPanelCollapsed(View panel) {
                //Log.e(TAG, "onPanelCollapsed");

            }

            @Override
            public void onPanelAnchored(View panel) {
                //Log.e(TAG, "onPanelAnchored");
            }

            @Override
            public void onPanelHidden(View panel) {
                //Log.e(TAG, "onPanelHidden");
            }
        });
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

}

