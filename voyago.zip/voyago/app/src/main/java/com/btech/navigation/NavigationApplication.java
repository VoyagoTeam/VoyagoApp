package com.btech.navigation;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.kodeguy.qrbarreader.R;

/****************************************************************************
 * @ClassdName:DyrctApplication
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is DyrctApplication.
 ***************************************************************************/

public class NavigationApplication extends Application
{

    private static NavigationApplication mInstance;
    private SharedPreferences sharedPreferences;



    @Override
    public void onCreate() {

        super.onCreate();
        //Crittercism.initialize(getApplicationContext(), Constans.CRITISISM_APP_ID);

        mInstance = this;
        sharedPreferences = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);


    }


    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);

    }


    public static NavigationApplication getmInstance() {
        return mInstance;
    }

    public static void setmInstance(NavigationApplication mInstance) {
        NavigationApplication.mInstance = mInstance;
    }

    public SharedPreferences getSharedPreferences() {
        return sharedPreferences;
    }

    public void setSharedPreferences(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    public void savePreferenceDataString(String key, String value) {
        Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public void savePreferenceDataBoolean(String key, Boolean value) {
        Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public void savePreferenceDataInt(String key, int value) {
        Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }


    public void clearePreferenceData() {
        Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }



    @Override
    public void onTerminate() {
        super.onTerminate();

        if (mInstance != null) {
            mInstance = null;
        }
    }


}
