package com.btech.navigation.model;

/**
 * Created by rohit on 10/15/15.
 */
public class Sys_ {

    private String pod;

    /**
     *
     * @return
     * The pod
     */
    public String getPod() {
        return pod;
    }

    /**
     *
     * @param pod
     * The pod
     */
    public void setPod(String pod) {
        this.pod = pod;
    }

}
