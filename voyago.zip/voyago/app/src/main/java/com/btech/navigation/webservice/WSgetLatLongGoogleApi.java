package com.btech.navigation.webservice;

import android.content.Context;


import com.kodeguy.qrbarreader.R;
import com.btech.navigation.comman.Constans;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;

/**
 * This class is used web service work SearchGooglePlace
 *
 * @author
 */
public class WSgetLatLongGoogleApi {


    private String message = "";
    private String data = "";
    private String input = "";
    private String key = "";
    private String types = "";
    private String sensor = "";
    private String parameters = "";
    private String output = "";
    private String url = "";
    private List<HashMap<String, String>> places = null;

    private Context mContext;
    private boolean isError;

    public boolean isError() {
        return isError;
    }

    /**
     * @param context
     */
    public WSgetLatLongGoogleApi(Context context) {
        super();
        this.mContext = context;


    }

    public String executeService(String search)
    {

        String latlong="";

        try {
            isError = false;
            String response = generateJsonReqResponce(search);
            latlong=parseJSON(response);

        } catch (Exception e) {
            e.printStackTrace();
            isError = true;
        }
        return latlong;

    }

    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();
            br.close();

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

    /**
     * Generate Request string
     *
     * @return
     */
    public String generateJsonReqResponce(String search_text)
    {

        try {
            // Obtain browser key from
            // https://code.google.com/apis/console
            key = "key=" + mContext.getString(R.string.google_android_api_key);
            input = "reference" + search_text;
            // place type to be searched
            //types = "types=(cities)";
            // Sensor enabled
            sensor = "sensor=true";
            // Building the parameters to the web
            // service
            parameters = input + "&" + sensor + "&" + key;
            // Output format
            output = "json";
            // Building the url to the web service
            url = Constans.GOOGLE_GET_LATLONG_URL + output + "?" + parameters;

            //Log.d("URL","URL:"+url);

            data = downloadUrl(url);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data.toString();
    }

    /**
     * Parse Json response
     */
    public String parseJSON(String jsonData)
    {
        String latlong = null;

        JSONObject jObjectResult;
        JSONObject jObjectgeometry;
        JSONObject jObjectLocation;
        JSONObject jObjectLat;

        try
        {
            jObjectResult = new JSONObject(jsonData);
            jObjectgeometry = new JSONObject(jObjectResult.getString("result"));
            jObjectLocation = new JSONObject(jObjectgeometry.getString("geometry"));
            jObjectLat = new JSONObject(jObjectLocation.getString("location"));

            latlong=jObjectLat.get("lat")+","+jObjectLat.get("lng");


        } catch (Exception e) {
            e.printStackTrace();
        }
        return latlong;

    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
