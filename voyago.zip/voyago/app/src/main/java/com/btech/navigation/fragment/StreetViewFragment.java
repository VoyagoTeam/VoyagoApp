package com.btech.navigation.fragment;


import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.btech.navigation.activity.BaseActivity;
import com.kodeguy.qrbarreader.R;

;


/****************************************************************************
 * @ClassdName:BaseFragment
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is use BaseFragment Of All Fragment .
 ***************************************************************************/

public class StreetViewFragment extends Fragment
{


    private Handler rotator;
    private Runnable runnable;
    private TextView mTitle;
    private Toolbar toolbar;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle SavedInstanceStatesavedInstanceState) {

        final View rootView = inflater.inflate(R.layout.fragment_streetview, null);
        //setupToolbar(rootView);
        updateUI(rootView);
        setupToolbar(rootView);


        return rootView;
    }

    private void setupToolbar(View view)
    {

        // Initializing Toolbar and setting it as the actionbar
        toolbar = (Toolbar) view.findViewById(R.id.activity_menubar_toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        //((AppCompatActivity) getActivity()).setSupportActionBar(((MainActivity) getActivity()).getToolbar());
        final ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        mTitle = (TextView) toolbar.findViewById(R.id.actionbar_tvTitle);
        mTitle.setVisibility(View.VISIBLE);
        mTitle.setText("STREETVIEW");
        actionBar.show();


        if (actionBar != null) {

            actionBar.setHomeAsUpIndicator(R.drawable.back_btn);
            actionBar.setTitle("");
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setHomeButtonEnabled(true);
        }



    }


    private void updateUI(final View rootView)
    {


        String mCurrentLocation = null;

        if (((BaseActivity) getActivity()).getCurrentLocation()!= null)
        {
            mCurrentLocation = ((BaseActivity) getActivity()).getCurrentLocation();
        }

        if (null != mCurrentLocation)
        {
            WebView webView = (WebView) rootView.findViewById(R.id.view);
            webView.getSettings().setJavaScriptEnabled(true);
            //webView.setWebViewClient(new WebViewClient());
            //webView.loadUrl( "file:///android_asset/mapa1.html");


            String mresult=getData(mCurrentLocation.split(",")[0],mCurrentLocation.split(",")[1]);

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.loadUrl(url);
                    return true;
                }
            });
            webView.loadData(mresult, "text/html; charset=UTF-8", null);
            //Uri uri = Uri.parse("https://maps.googleapis.com/maps/api/streetview?size=600x300&location=23,72&heading=151.78&pitch=-0.76&key=AIzaSyBNIUUOroyzArwf4s3wxV3fckObHrzbD-o");
            //webView.loadUrl(uri.toString());
        }
        else
        {
            rotator = new Handler();
            runnable = new Runnable() {
                public void run() {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    updateUI(rootView);

                }
            };

            rotator.postDelayed(runnable, 3000);
        }




    }

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }





    private String getData(String s, String s1) {



        String test="<html>\n" +
                "<head>\n" +
                "    <meta charset=\"utf-8\">\n" +
                "    <title>Street View side-by-side</title>\n" +
                "    <style>\n" +
                "        html, body {\n" +
                "        height: 100%;\n" +
                "        margin: 0;\n" +
                "        padding: 0;\n" +
                "        }\n" +
                "        #map, #pano {\n" +
                "        float: bottom;\n" +
                "        height: 50%;\n" +
                "        width: 100%;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div id=\"map\"></div>\n" +
                "<div id=\"pano\"></div>\n" +
                "<script>\n" +
                "\n" +
                "      function initialize() {\n" +
                "        var fenway = {lat: "+s+", lng: "+s1+"};\n" +
                "        var map = new google.maps.Map(document.getElementById('map'),\n" +
                "         {\n" +
                "          center: fenway,\n" +
                "          mapTypeId: google.maps.MapTypeId.ROADMAP,\n" +
                "          zoom: 14\n" +
                "        });\n" +
                "        var panorama = new google.maps.StreetViewPanorama(\n" +
                "            document.getElementById('pano'), {\n" +
                "              position: fenway,\n" +
                "\n" +
                "        linksControl: false,\n" +
                "        panControl: false,\n" +
                "        addressControl :false,\n" +
                "        enableCloseButton: false,\n" +
                "              pov: {\n" +
                "                heading: 34,\n" +
                "                pitch: 10\n" +
                "              }\n" +
                "            });\n" +
                "        map.setStreetView(panorama);\n" +
                "      }\n" +
                "    </script>\n" +
                "<script async defer\n" +
                "        src=\"https://maps.googleapis.com/maps/api/js?key= AIzaSyDFtgR4LpDEfCVfcsPq9xxjpOuaZt3Nxv0&callback=initialize\">\n" +
                "</script>\n" +
                "</body>\n" +
                "</html>";


        return test;


    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if(rotator !=null)
        {
            rotator.removeCallbacks(runnable);
        }
    }

   /* AIzaSyCqQTMvvp2MrqNvIbP-V2VOLRCzd9g9rZE*/
    /*AIzaSyDFtgR4LpDEfCVfcsPq9xxjpOuaZt3Nxv0*/
}