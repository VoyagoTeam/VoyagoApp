package com.btech.navigation.model;

/**
 * Created by rohit on 10/15/15.
 */
public class Rain {


}