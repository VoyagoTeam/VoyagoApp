package com.btech.navigation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kodeguy.qrbarreader.R;
import com.btech.navigation.model.MapInfoModel;

import java.util.ArrayList;
import java.util.List;

/****************************************************************************
 * @ClassdName:MapInstractionListAdapter
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This class is use to Adapter on MapInfoList
 ***************************************************************************/

public class MapInstractionListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<MapInfoModel> MapInfoList = null;

    public MapInstractionListAdapter( Context context, List<MapInfoModel> MapInfoListArr) {

        this.context = context;
        this.MapInfoList = (ArrayList<MapInfoModel>) MapInfoListArr;




    }


    @Override
    public int getCount() {

        return MapInfoList.size();
    }

    @Override
    public MapInfoModel getItem(int position) {
        return MapInfoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    /****************************************************************************
     * @Method:-getView
     * @purpose:This method use to Declaration of view & initializeComponent .
     ***************************************************************************/

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final Holder holder;

        if (convertView == null) {
            holder = new Holder();
            convertView = LayoutInflater.from(context).inflate(R.layout.row_root_insraction_list, null);

            holder.tvMapDesInfo = (TextView) convertView.findViewById(R.id.row_rootinstraction_tvMapDesInfo);
            holder.ivInstIcon = (ImageView) convertView.findViewById(R.id.row_rootinstraction_ivInstIcon);

            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        holder.tvMapDesInfo.setText("" + MapInfoList.get(position).getDescription());


        if (MapInfoList.get(position).getTitle().equalsIgnoreCase("left")) {
            holder.ivInstIcon.setBackgroundResource(R.drawable.turn_left);
        } else if (MapInfoList.get(position).getTitle().equalsIgnoreCase("right")) {
            holder.ivInstIcon.setBackgroundResource(R.drawable.turn_right);
        } else {
            holder.ivInstIcon.setBackgroundResource(R.drawable.turn_streat_arro);
        }


        return convertView;
    }

    class Holder {

        private TextView tvMapDesInfo;
        private ImageView ivInstIcon;


    }


}
