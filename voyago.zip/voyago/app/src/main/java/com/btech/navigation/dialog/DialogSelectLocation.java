package com.btech.navigation.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;

import com.kodeguy.qrbarreader.R;
import com.btech.navigation.adapter.GooglePlacesAutocompleteAdapterNew;
import com.btech.navigation.webservice.WSgetLatLongGoogleApi;

/****************************************************************************
 * @ClassdName:DialogExportTrip
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This class is use to Export CSV
 ***************************************************************************/

public class DialogSelectLocation extends DialogFragment {

    // Member fields

    private AutoCompleteTextView tvSearch;


    private View view;
    private String startLocation;
    private String startLatLong;
    private  GetLocationAddressAsync mGetLocationAddressAsync;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //view = inflater.inflate(R.layout.dialog_select_location, container, false);
        final Dialog dialog = new Dialog(getActivity());

        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.setContentView(R.layout.dialog_select_location);
        initializeComponent(dialog);

        return view;
    }

    protected void initializeComponent(Dialog v) {
        getActivity().setResult(Activity.RESULT_CANCELED);



        tvSearch=(AutoCompleteTextView)v.findViewById(R.id.tvSearch) ;
        tvSearch.setAdapter(new GooglePlacesAutocompleteAdapterNew(getActivity()));
        tvSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick (AdapterView<?> adapterView, View view, int position, long id) {


                //Util.hideKeyboard(getActivity());
                startLocation = (String) adapterView.getItemAtPosition(position);
                addressToLatlong(startLocation);
                //tvStart.setText(""+startLocation.split("===")[0]);
                tvSearch.dismissDropDown();
                Log.d("startLocation","startLocation=="+startLocation);
            }
        });





    }








    private void addressToLatlong(String reference) {

        if (mGetLocationAddressAsync != null && mGetLocationAddressAsync.getStatus() == AsyncTask.Status.PENDING) {
            mGetLocationAddressAsync.execute();
        } else if (mGetLocationAddressAsync == null || mGetLocationAddressAsync.getStatus() == AsyncTask.Status.FINISHED) {
            mGetLocationAddressAsync = new GetLocationAddressAsync(reference, getActivity());
            mGetLocationAddressAsync.execute();
        }


    }

    private class GetLocationAddressAsync extends AsyncTask<String, Void, String>
    {

        // boolean duplicateResponse;
        String reference;
        String address;
        String latlong;

        WSgetLatLongGoogleApi mWSgetLatLongGoogleApi;

        public GetLocationAddressAsync(String reference,final Context context)
        {
            this.reference = reference.split("==")[1];
            this.address=reference.split("==")[0];

        }

        @Override
        protected void onPreExecute()
        {

        }

        @Override
        protected String doInBackground(String... params)
        {


            mWSgetLatLongGoogleApi = new WSgetLatLongGoogleApi(getActivity());
            latlong=mWSgetLatLongGoogleApi.executeService(reference);
            return null;

        }

        @Override
        protected void onPostExecute(String result) {

            double lat = Double.parseDouble(latlong.split(",")[0]);
            double lng = Double.parseDouble(latlong.split(",")[1]);
            startLatLong = String.valueOf(lat + "," + lng);
            startLocation=startLocation.split("===")[0];
            dismiss();

                Intent intent = new Intent();
                intent.putExtra("startLocation", startLocation);
                intent.putExtra("startLatLong", startLatLong);
                getTargetFragment().onActivityResult(getTargetRequestCode(), 99, intent);
                Log.d("NavigationView","startAdd=="+startLocation);
                Log.d("NavigationView","startLatLong=="+startLatLong);







        }


    }


}
