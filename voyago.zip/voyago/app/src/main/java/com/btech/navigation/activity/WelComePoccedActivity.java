package com.btech.navigation.activity;


import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.btech.navigation.NavigationApplication;
import com.kodeguy.qrbarreader.R;


public class WelComePoccedActivity extends Activity {

    private Animation animation;
    private ImageView logo;
    private TextView txtDone;
    private TextView txtWellcome;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_procced);

        logo = (ImageView) findViewById(R.id.logo_img);
        txtDone = (TextView) findViewById(R.id.tvDone);
        txtWellcome = (TextView) findViewById(R.id.pro_txt);

        txtDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNavigated();
            }
        });


        if (savedInstanceState == null) {
            flyIn();
        }


    }

    private void flyIn()
    {
        animation = AnimationUtils.loadAnimation(this, R.anim.logo_animation);
        logo.startAnimation(animation);

        animation = AnimationUtils.loadAnimation(this, R.anim.pro_animation);
        txtWellcome.startAnimation(animation);
    }

    private void endSplash() {
        animation = AnimationUtils.loadAnimation(this, R.anim.logo_animation_back);
        logo.startAnimation(animation);


        animation = AnimationUtils.loadAnimation(this, R.anim.pro_animation_back);
        txtWellcome.startAnimation(animation);


    }

    private void openNavigated()
    {

        if (ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED)
        {

            ActivityCompat.requestPermissions(WelComePoccedActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);

            // MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION is an
            // app-defined int constant. The callback method gets the
            // result of the request.
        }
        else
        {
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isWellcome), true);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the task you need to do.
                    Toast.makeText(getApplicationContext(),"PERMISSION_GRANTED",Toast.LENGTH_LONG).show();

                    NavigationApplication.getmInstance().savePreferenceDataBoolean(getString(R.string.isWellcome), true);

                    Intent i=new Intent(getApplicationContext(),MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    finish();


                } else {
                    Toast.makeText(getApplicationContext(),"PERMISION DENIDED",Toast.LENGTH_LONG).show();
                    // permission denied, boo! Disable the functionality that depends on this permission.
                }
                return;
            }
        }
    }
    @Override
    public void onBackPressed() {
        // Do nothing
    }

}
