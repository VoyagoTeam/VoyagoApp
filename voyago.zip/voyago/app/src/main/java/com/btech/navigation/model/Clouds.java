package com.btech.navigation.model;

/**
 * Created by rohit on 10/15/15.
 */
public class Clouds {

    private Integer all;

    /**
     *
     * @return
     * The all
     */
    public Integer getAll() {
        return all;
    }

    /**
     *
     * @param all
     * The all
     */
    public void setAll(Integer all) {
        this.all = all;
    }

}