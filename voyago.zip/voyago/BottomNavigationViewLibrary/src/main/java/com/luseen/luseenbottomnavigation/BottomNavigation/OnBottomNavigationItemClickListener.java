package com.luseen.luseenbottomnavigation.BottomNavigation;

/**
 * Created by Chatikyan on 31.03.2016.
 */
public interface OnBottomNavigationItemClickListener {
    void onNavigationItemClick(int index);
}
